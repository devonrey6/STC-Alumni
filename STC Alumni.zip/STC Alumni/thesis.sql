-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 10, 2019 at 09:54 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thesis`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_account`
--

CREATE TABLE `admin_account` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_account`
--

INSERT INTO `admin_account` (`id`, `username`, `password`, `name`, `status`) VALUES
(1, 'devon', '123', 'devon', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `alumni_account`
--

CREATE TABLE `alumni_account` (
  `id` int(8) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `alumni_id` int(8) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alumni_account`
--

INSERT INTO `alumni_account` (`id`, `username`, `password`, `alumni_id`, `status`) VALUES
(1, 'devon', '1212', 12312, 'active'),
(2, 'joenna', '123456', 1234, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `alumni_educationalback`
--

CREATE TABLE `alumni_educationalback` (
  `id` int(10) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `college_university` varchar(100) NOT NULL,
  `year_grad` varchar(100) NOT NULL,
  `honor` varchar(100) NOT NULL,
  `name_of_examination` varchar(100) NOT NULL,
  `date_taken` date NOT NULL,
  `rating` varchar(100) NOT NULL,
  `14_1` varchar(100) NOT NULL,
  `14_2` varchar(100) NOT NULL,
  `14_3` varchar(100) NOT NULL,
  `14_4` varchar(100) NOT NULL,
  `14_5` varchar(100) NOT NULL,
  `14_6` varchar(100) NOT NULL,
  `14_7` varchar(100) NOT NULL,
  `14_8` varchar(100) NOT NULL,
  `14_9` varchar(100) NOT NULL,
  `14_10` varchar(100) NOT NULL,
  `14_11` varchar(100) NOT NULL,
  `14_12` varchar(100) NOT NULL,
  `14_13` varchar(100) NOT NULL,
  `14_14` varchar(100) NOT NULL,
  `14_specify` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alumni_educationalback`
--

INSERT INTO `alumni_educationalback` (`id`, `degree`, `college_university`, `year_grad`, `honor`, `name_of_examination`, `date_taken`, `rating`, `14_1`, `14_2`, `14_3`, `14_4`, `14_5`, `14_6`, `14_7`, `14_8`, `14_9`, `14_10`, `14_11`, `14_12`, `14_13`, `14_14`, `14_specify`) VALUES
(2, 'Master of Arts in Education (MAED)Master of Arts in Education (MAED)Master of Arts in Education (MAE', 'qweqweqwe', '2018-10-02', 'qweqweqwe', 'qweqweqwe', '2018-10-18', 'qweqwe', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'Undergraduate/AB/BS', 'qweqwe'),
(3, 'Master of Arts in Education (MAED)Master of Arts in Education (MAED)Master of Arts in Education (MAE', 'qweqwe', '2018-10-02', 'qweqwe', 'qweqwe', '2018-10-04', 'qweqwe', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', 'Graduate/MS/Ph.D', '');

-- --------------------------------------------------------

--
-- Table structure for table `alumni_generalinfo`
--

CREATE TABLE `alumni_generalinfo` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact_number` varchar(11) NOT NULL,
  `mobile_number` varchar(11) NOT NULL,
  `civil_status` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `birthday` varchar(100) NOT NULL,
  `region_of_origin` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `residence` varchar(100) NOT NULL,
  `alumni_account_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alumni_generalinfo`
--

INSERT INTO `alumni_generalinfo` (`id`, `fname`, `lname`, `mname`, `address1`, `address2`, `email`, `contact_number`, `mobile_number`, `civil_status`, `gender`, `birthday`, `region_of_origin`, `province`, `residence`, `alumni_account_id`) VALUES
(2, 'qweqweqwe', 'qwqwe', 'qweqwe', 'qweqw', 'eqwe', 'devonreydonasco@gmail.com', '23123123', '12312312312', 'Single', 'male', '2018-10-19', 'Region 1', 'qweqwe', 'City', 1),
(3, 'devon', 'dqweqw', 'eqwe', 'qweqw', 'qweqwe', 'donasco_danielle08@icloud.com', '1231231', '23123123', 'Single', 'male', '2018-10-03', 'Region 1', 'qweqwe', 'City', 2);

-- --------------------------------------------------------

--
-- Table structure for table `employment_data`
--

CREATE TABLE `employment_data` (
  `id` int(8) NOT NULL,
  `present_employed` varchar(100) NOT NULL,
  `reason_not_employed` varchar(100) NOT NULL,
  `present_employment_status` varchar(100) NOT NULL,
  `present_occupation` varchar(100) NOT NULL,
  `name_of_company` varchar(100) NOT NULL,
  `major_line_business` varchar(100) NOT NULL,
  `place_of_work` varchar(100) NOT NULL,
  `first_job_college` varchar(100) NOT NULL,
  `reason_stay_job` varchar(100) NOT NULL,
  `first_job_related_cours` varchar(100) NOT NULL,
  `reason_accepting_job` varchar(100) NOT NULL,
  `reason_changing_job` varchar(100) NOT NULL,
  `stay_long_first_job` varchar(100) NOT NULL,
  `find_long_first_job` varchar(100) NOT NULL,
  `take_long_first_job` varchar(100) NOT NULL,
  `rank_clerical` varchar(100) NOT NULL,
  `technical_supervisory` varchar(100) NOT NULL,
  `managerial_executive` varchar(100) NOT NULL,
  `self_employed` varchar(100) NOT NULL,
  `gross_income_monthly` varchar(100) NOT NULL,
  `curriculum_relevant_first_job` varchar(100) NOT NULL,
  `competencies_learned_useful` varchar(100) NOT NULL,
  `suggestion` varchar(100) NOT NULL,
  `current_job_related` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employment_data`
--

INSERT INTO `employment_data` (`id`, `present_employed`, `reason_not_employed`, `present_employment_status`, `present_occupation`, `name_of_company`, `major_line_business`, `place_of_work`, `first_job_college`, `reason_stay_job`, `first_job_related_cours`, `reason_accepting_job`, `reason_changing_job`, `stay_long_first_job`, `find_long_first_job`, `take_long_first_job`, `rank_clerical`, `technical_supervisory`, `managerial_executive`, `self_employed`, `gross_income_monthly`, `curriculum_relevant_first_job`, `competencies_learned_useful`, `suggestion`, `current_job_related`) VALUES
(2, 'yes', 'Family concern and decided not to find a job', ' Temporary', 'Service workers and Shop and Market Sales Workers', '', 'Mining and Quarrying', 'Local', 'Yes', 'Related to special skill', 'No', 'Salaries and benefits', 'Salaries and benefits', 'Less than a month', 'Response to an advertisement', ' Less than a month', 'First Job', 'First Job', 'First Job', 'First Job', 'P 5,000.00 to less than P 10,000.00 ', 'Yes', 'Communication skills', '', 'Yes'),
(3, 'no', 'Family concern and decided not to find a job', 'Regular or Permanent', 'Service workers and Shop and Market Sales Workers', '', 'Agriculture, Hunting and Forestry', 'Local', 'Yes', 'Related to special skill', 'Yes', 'Salaries and benefits', 'Salaries and benefits', 'Less than a month', 'Response to an advertisement', ' Less than a month', 'First Job', 'First Job', 'First Job', 'First Job', ' Below P 5,000.00', 'Yes', 'Communication skills', '', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `graduate_list`
--

CREATE TABLE `graduate_list` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `bdate` varchar(100) NOT NULL,
  `bplace` varchar(100) NOT NULL,
  `present_add` varchar(100) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `year_grad` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(8) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` longblob NOT NULL,
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `image_post_update`
--

CREATE TABLE `image_post_update` (
  `id` int(8) NOT NULL,
  `date` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `post_updates`
--

CREATE TABLE `post_updates` (
  `id` int(8) NOT NULL,
  `date` varchar(100) NOT NULL,
  `update_post` varchar(1000) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `name` varchar(100) NOT NULL,
  `number` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`name`, `number`) VALUES
('Number of Alumni that says Yes that the course they took up in college is related to their first job', 1),
('Number of Alumni that says No that the course they took up in college is related to their first job', 1),
('Number of Alumni that says Yes that their current job is related to their course', 1),
('Number of Alumni that says No that their current job is related to their course', 1),
('Number Of Registered Alumni', 1),
('Number Of Alumni', 1),
('Number Of Employed Alumni', 1),
('Number Of Unemployed Alumni', 1);

-- --------------------------------------------------------

--
-- Table structure for table `training_advance_studies_attended`
--

CREATE TABLE `training_advance_studies_attended` (
  `id` int(8) NOT NULL,
  `title_of_training` varchar(100) NOT NULL,
  `duration_credits_earned` varchar(100) NOT NULL,
  `name_training_college` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `training_advance_studies_attended`
--

INSERT INTO `training_advance_studies_attended` (`id`, `title_of_training`, `duration_credits_earned`, `name_training_college`) VALUES
(2, 'qweqw', 'qwqwe', 'qweqweqwe'),
(3, 'qweqw', 'qwq', 'weqweqwe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_account`
--
ALTER TABLE `admin_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alumni_account`
--
ALTER TABLE `alumni_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alumni_educationalback`
--
ALTER TABLE `alumni_educationalback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alumni_generalinfo`
--
ALTER TABLE `alumni_generalinfo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alumni_account_id` (`alumni_account_id`);

--
-- Indexes for table `employment_data`
--
ALTER TABLE `employment_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `graduate_list`
--
ALTER TABLE `graduate_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alumni_account_id` (`username`);

--
-- Indexes for table `image_post_update`
--
ALTER TABLE `image_post_update`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_updates`
--
ALTER TABLE `post_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_advance_studies_attended`
--
ALTER TABLE `training_advance_studies_attended`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_account`
--
ALTER TABLE `admin_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `alumni_account`
--
ALTER TABLE `alumni_account`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `alumni_educationalback`
--
ALTER TABLE `alumni_educationalback`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `alumni_generalinfo`
--
ALTER TABLE `alumni_generalinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employment_data`
--
ALTER TABLE `employment_data`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `graduate_list`
--
ALTER TABLE `graduate_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `image_post_update`
--
ALTER TABLE `image_post_update`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `post_updates`
--
ALTER TABLE `post_updates`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `training_advance_studies_attended`
--
ALTER TABLE `training_advance_studies_attended`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `alumni_generalinfo`
--
ALTER TABLE `alumni_generalinfo`
  ADD CONSTRAINT `alumni_generalinfo_ibfk_1` FOREIGN KEY (`alumni_account_id`) REFERENCES `alumni_account` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
