<?php
    include 'connection.php';

?>
<html>
	<head>
		<title>Alumni List</title>
        
        <style>
            table{
                border-collapse: collapse;
                width: 100%;
                color: black;
                font-family: sans-serif;
                font-size: 13px;
                text-align: center;
                
            }
            th{
                background-color: #800000;
                color: white;
                width: 10%
            }
        </style>
        
		<link href="css/alumni.css" rel="stylesheet" type="text/css">
	</head>
	
	<body >
		<div class="loginbox">
		<img src="images/avatar.png" class="avatar">
		<h1>Alumni List</h1>
            
            <table>
                    <th align="center">Name</th>
                    <th align="center">Gender</th>
                    <th align="center">Civil Status</th>
                    <th align="center">Birthday</th>
            <?php
                    
                        $sql = "SELECT name, gender, civil_status, birthday FROM alumni_generalinfo";
                        $result = $conn-> query($sql);

                        if($result-> num_rows > 0) {
                            while ($row = $result -> fetch_assoc()){
                                echo "<tr><td>". $row["name"]. "</td>
                                <td>" .$row["gender"]. "</td>
                                <td>" .$row["civil_status"]. "</td>
                                <td>" .$row["birthday"]. "</td></tr>"; 
                            }
                            echo "</table>";
                        }
                        else{
                            echo "0 result";
                        }
                    ?>
		<form>
			
            <a href="index.php" style="padding-bottom: 100px;">Back to Home</a>
		<form>
		</div>
	</body>
</html>