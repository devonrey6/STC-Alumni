<?php
    include "connection.php";
    session_start();
    
    $query = "SELECT name, sum(number) FROM reports group by name";
    $res = $conn->query($query);
    
    
?>

<html>
	<head>
		<title>Reports</title>
        
		<link href="css/reports.css" rel="stylesheet" type="text/css">
        
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
          google.charts.load('current', {'packages':['corechart']});
          google.charts.setOnLoadCallback(drawChart);

          function drawChart() {

            var data = google.visualization.arrayToDataTable([
              ['Name', 'Number'],
                <?php

                    while($row=$res->fetch_assoc()){

                        echo "['".$row['name']."',".$row['sum(number)']."],";

                    }


                ?>
            ]);

            var options = {
              title: 'Statistics of Alumni'
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart'));

            chart.draw(data, options);
          }
        </script>
        
	</head>
	
	<body style="background-color:#800000">
		<div class="loginbox" style="width: 980px; height: 850px;">
        <h1>Reports</h1>
        
		
		
		    <form>
                <?php if(isset($_SESSION['username'])): ?>
                <div id="piechart" style="width: 920px; height: 500px; padding-right: 20px; background: #cac5c5;"></div>
                <?php 
                
                    $sqlNumberAlumni = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni'";
                    $result1 = mysqli_query($conn, $sqlNumberAlumni);
                    while($row=mysqli_fetch_array($result1)){
                        $postNumberAlum=$row['num'];
                    }
                    ////////////
                    $sqlNumberRegAlumni = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number Of Registered Alumni'";
                    $result2 = mysqli_query($conn, $sqlNumberRegAlumni);
                    while($row=mysqli_fetch_array($result2)){
                        $postNumberRegAlum=$row['num'];
                    }
                    ///////////
                    $sqlNumberEmpAlumni = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number Of Employed Alumni'";
                    $result3 = mysqli_query($conn, $sqlNumberEmpAlumni);
                    while($row=mysqli_fetch_array($result3)){
                        $postNumberEmpAlumni=$row['num'];
                    }
                    /////////
                    $sqlNumberUnempAlumni = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number Of Unemployed Alumni'";
                    $result4 = mysqli_query($conn, $sqlNumberUnempAlumni);
                    while($row=mysqli_fetch_array($result4)){
                        $postNumberUnempAlumni=$row['num'];
                    }
                    ////////
                    $sqlFjobRelated = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni that says Yes that the course they took up in college is related to their first job'";
                    $result5 = mysqli_query($conn, $sqlFjobRelated);
                    while($row=mysqli_fetch_array($result5)){
                        $postFjobRelated=$row['num'];
                    }
                    ///////
                    $sqlFjobRelatedNo = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni that says No that the course they took up in college is related to their first job'";
                    $result6 = mysqli_query($conn, $sqlFjobRelatedNo);
                    while($row=mysqli_fetch_array($result6)){
                        $postFjobRelatedNo=$row['num'];
                    }
                    //////
                    $sqlCjobRelated = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni that says Yes that their current job is related to their course'";
                    $result7 = mysqli_query($conn, $sqlCjobRelated);
                    while($row=mysqli_fetch_array($result7)){
                        $postCjobRelated=$row['num'];
                    }
                    //////
                    $sqlCjobRelatedNo = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni that says No that their current job is related to their course'";
                    $result8 = mysqli_query($conn, $sqlCjobRelatedNo);
                    while($row=mysqli_fetch_array($result8)){
                        $postCjobRelatedNo=$row['num'];
                    }
                ?>
                <h2 style="color:black; font-size: 15px;">Report: As of 2018 Saint Theresa College; </h2>
                
                 
                <ul style="color:black;">
                    <li>Number of Alumni: <?php echo $postNumberAlum ?></li>
                    <li>Number of Registered Alumni: <?php echo $postNumberRegAlum ?></li>
                    <li>Number Of Employed Alumni: <?php echo $postNumberEmpAlumni ?></li>
                    <li>Number Of Unemployed Alumni: <?php echo $postNumberUnempAlumni ?></li>
                    <li>Number of Alumni that says Yes that the course they took up in college is related to their first job: <?php echo $postFjobRelated ?></li>
                    <li>Number of Alumni that says No that the course they took up in college is related to their first job: <?php echo $postFjobRelatedNo ?></li>
                    <li>Number of Alumni that says Yes that their current job is related to their course <?php echo $postCjobRelated ?></li>
                    <li>Number of Alumni that says No that their current job is related to their course <?php echo $postCjobRelatedNo ?></li>
                </ul>
                
                
                <?php else: ?>
                <h1>Please Login first</h1>
                <?php endif; ?>
                
                <a href="index.php">Back to Home</a>
                
                
            </form>
		</div>
	</body>
</html>