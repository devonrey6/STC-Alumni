<?php
    include "connection.php";
    session_start();
    if(isset($_POST['submit'])){
        $user = $_POST['username'];
        $pass = $_POST['password'];
        
        $query = "SELECT * FROM alumni_account WHERE username = '$user' AND password = '$pass' AND status = 'active';";
        
        $run = mysqli_query ($conn, $query);
        if(mysqli_num_rows($run)>0){
            echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
            header("location: user.php");
            $_SESSION['username'] = $user;
        }else{
            echo "<script type='text/javascript'>alert('Username and Password Incorrect.. If you have already registered please wait for the confirmation of the admin for your account!')</script>";
        }
    }

?>
<html>
	<head>
		<title>Login</title>
		<link href="css/login.css" rel="stylesheet" type="text/css">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	</head>
	
	<body >
		<div class="loginbox">
		<img src="images/avatar.png" class="avatar">
		<h1> LOGIN</h1>
		<form action="login.php" method="post">
            
			<p>Username</p>
			<input type="text" name="username" placeholder="Enter Username" required>
			<p>Password</p>
			<input type="password" name="password" placeholder="Enter Password" required>
			<input type="submit" name="submit" value="Login">
            <a href="loginAdmin.php">Administrator Login</a><br>
			<a href="register.php">Don't have an account? Register Now!</a> <br><br>
			<a href="index.php">Back to Home</a>
		<form>
		</div>
	</body>
</html>