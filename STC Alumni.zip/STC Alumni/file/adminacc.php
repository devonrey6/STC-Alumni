<?php
    include "connection.php";
    session_start();

    if(isset($_POST['UPDATEADMIN'])){
        $active = 'active';
        $alumniID = $_POST['setActAdmin'];
        
        $query1 = "UPDATE admin_account SET status = 'active' WHERE id = $alumniID";
        
        if(mysqli_query($conn, $query1)){
            header("location: adminacc.php");
        }
        else{
            echo mysqli_error();
        }
    }

    
    if(isset($_POST['UPDATEADMININACT'])){
        $active = 'active';
        $alumniID = $_POST['setInactAdmin'];
        
        $queryAct = "UPDATE admin_account SET status = 'inactive' WHERE id = $alumniID";
        
        if(mysqli_query($conn, $queryAct)){
            header("location: adminacc.php");
        }
        else{
            echo mysqli_error();
        }
    }


    
?>


<html>
	<head>
		<title>Admin</title>
        
        <style>
            #nav1 h1{
                float: left;
                font-size: 2.5em;
                margin-left: 15px;
                padding-left: 30px;
            }
            #nav1 h1 a{
                text-decoration: none;
                color: white;
            }
            #nav1 ul{
                float: right;
                margin-right: 15px;
            }
            #nav1 ul li{
                display: inline-block;
                list-style-type: none;

            }
            #nav1 ul li a{
                text-decoration: none;
                color: black;
                padding: 25px;
            }
            #nav1 ul li:hover{
                background: #a09e9e;
                transition: all ease-in-out 0.45s;
            }
            table {
                border-collapse: collapse;
                width: 70%;
                color: black;
                font-family: sans-serif;
                font-size: 14px;
                text-align: left;
            }
            th{
                background-color: #800000;
                color: white;
                width: 10%
            }
            body{
                background-color: #800000;
            }
            hr{
                color: #800000;
            }
        </style>
        
		
        <link href="css/admin.css" rel="stylesheet" type="text/css">
	</head>
	
	<body background="back.png" style="background-color: #800000">
		<div class="loginbox" style="height: 600px; width: 1100px; overflow:auto;  ">
		
		<?php if(isset($_SESSION['usernameAdmin'])): ?>
            
		<form action="adminacc.php" method="post">
            
            <div id="nav1">
                
                <ul>
                    <?php 
                        $queryNumAlum = "SELECT COUNT(*) AS count FROM alumni_account WHERE status = 'inactive'";
                        $resultNumAlum = $conn-> query($queryNumAlum);

                        while ($row = $resultNumAlum->fetch_assoc()) {

                        $resNumAlum = $row['count'];
                            echo '<li id="active"><a href="adminacc.php" style="font-size:15px;"> Admin Account</a></li>';
                            if($resNumAlum > 0) {
                                echo '<li><a href="admininfo.php" style="color:red; font-size:15px;"> Information Notification/Report ('.$resNumAlum.')</a></li>';
                            }
                            else {
                                echo '<li><a href="admininfo.php" style="font-size:15px;"> Information Notification/Report ('.$resNumAlum.')</a></li>';
                            }
                            echo '<li><a href="adminannc.php" style="font-size:15px;"> Announcement and School Update</a></li>';
                            echo '<li><a href="admingrad.php" style="font-size:15px;"> Graduate List</a></li>';
                            echo '<li><a href="logout.php" style="font-size:15px;"> Logout</a></li>';
                        }
                    ?>
                </ul>
		    </div>
            
            <br><br><br><br><br>
            
            <div class="panel1">
                
                
                <b>Update Alumni Pie Chart Statistics</b>
                    <br><br>
                    
                <table border="1" frame="hsides" rules="rows" style="width: 100%">
                    
                    
                    <?php
                    echo "<tr>";
                    $queryNumAlum = "SELECT COUNT(*) AS count FROM graduate_list";
                    $resultNumAlum = $conn-> query($queryNumAlum);

                    while ($row = $resultNumAlum->fetch_assoc()) {

                    $resNumAlum = $row['count'];
                    echo "<td><h2>Number of Alumni: $resNumAlum</h2></td>";
                    }
                    //end td
                    
                    $sqlNumberAlumni = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni'";
                    $result1 = mysqli_query($conn, $sqlNumberAlumni);
                    while($row=mysqli_fetch_array($result1)){
                        $postNumberAlum=$row['num'];
                        echo "<td><h2>Number of Alumni(Chart): $postNumberAlum</h2></td>";    
                    }
                    
                    $holdNumAlum = $resNumAlum - $postNumberAlum;
                    echo "<td><h2>To be added Number of Alumni: $holdNumAlum</h2></td>";
                    
                    echo "</tr>";
                    ////------------------------------------------------------////
                    echo "<tr>";
                    $queryEmpAlum = "SELECT COUNT(present_employed) AS count FROM employment_data WHERE present_employed='yes'";
                    $resultEmpAlum = $conn-> query($queryEmpAlum);

                    while ($row = $resultEmpAlum->fetch_assoc()) {

                    $resEmpAlum = $row['count'];
                    echo "<td><h2>Number of Employed Alumni: $resEmpAlum</h2></td>";
                    }
                    //end td
                    
                    $sqlNumberEmpAlumni = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number Of Employed Alumni'";
                    $result3 = mysqli_query($conn, $sqlNumberEmpAlumni);
                    while($row=mysqli_fetch_array($result3)){
                        $postNumberEmpAlumni=$row['num'];
                        echo "<td><h2>Number of Employed Alumni(Chart): $postNumberEmpAlumni</h2></td>";
                    }
                    
                    $holdEmpAlum = $resEmpAlum - $postNumberEmpAlumni;
                    echo "<td><h2>To be added Number Employed of Alumni: $holdEmpAlum</h2></td>";
                    
                    echo "</tr>";
                    ////------------------------------------------------------////
                    echo "<tr>";
                    $queryRegAlum = "SELECT COUNT(*) AS count FROM alumni_account";
                    $resultRegAlum = $conn-> query($queryRegAlum);

                    while ($row = $resultRegAlum->fetch_assoc()) {

                    $resRegAlum = $row['count'];
                    echo "<td><h2>Number of Registered Alumni: $resRegAlum</h2></td>";
                    }
                    //end td
                    $sqlNumberRegAlumni = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number Of Registered Alumni'";
                    $result2 = mysqli_query($conn, $sqlNumberRegAlumni);
                    while($row=mysqli_fetch_array($result2)){
                        $postNumberRegAlum=$row['num'];
                        echo "<td><h2>Number of Registered Alumni(Chart): $postNumberRegAlum</h2></td>";
                    }
                    $holdNumberRegAlumni = $resRegAlum - $postNumberRegAlum;
                    echo "<td><h2>To be added Number of Registered Alumni: $holdNumberRegAlumni</h2></td>";
                    echo "</tr>";
                    ////------------------------------------------------------////
                    
                    echo "<tr>";
                    $queryUnempAlum = "SELECT COUNT(present_employed) AS count FROM employment_data WHERE present_employed='no'";
                    $resultUnempAlum = $conn-> query($queryUnempAlum);

                    while ($row = $resultUnempAlum->fetch_assoc()) {

                    $resUnempAlum = $row['count'];
                    echo "<td><h2>Number of Unemployed Alumni: $resUnempAlum</h2></td>";
                    }
                    //end td
                    $sqlNumberUnempAlumni = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number Of Unemployed Alumni'";
                    $result4 = mysqli_query($conn, $sqlNumberUnempAlumni);
                    while($row=mysqli_fetch_array($result4)){
                        $postNumberUnempAlumni=$row['num'];
                        echo "<td><h2>Number of Unemployed Alumni(Chart): $postNumberUnempAlumni</h2></td>";
                    
                    }
                    $holdNumberUnempAlum = $resUnempAlum - $postNumberUnempAlumni;
                    echo "<td><h2>To be added Number of Unemployed Alumni: $holdNumberUnempAlum</h2></td>";
                    
                    echo "</tr>";
                    //end td
                    
                    
                    //-------------------//
                    echo "<tr>";
                    $queryFjobRelated = "SELECT COUNT(*) AS count FROM employment_data WHERE first_job_related_cours='Yes'";
                    $resultFjobRelated = $conn-> query($queryFjobRelated);

                    while ($row = $resultFjobRelated->fetch_assoc()) {

                    $resFjobRelated = $row['count'];
                    echo "<td><h2>Number of Alumni that says Yes that the course they <br> took up in college is related to their first job: $resFjobRelated</h2></td>";
                    }
                    
                    $sqlFjobRelated = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni that says Yes that the course they took up in college is related to their first job'";
                    $result5 = mysqli_query($conn, $sqlFjobRelated);
                    while($row=mysqli_fetch_array($result5)){
                        $postFjobRelated=$row['num'];
                        echo "<td><h2>Chart(yes): $postFjobRelated</h2></td>";    
                    }
                    
                    $holdFjobRelated = $resFjobRelated - $postFjobRelated;
                    echo "<td><h2>To be added on the chart: $holdFjobRelated</h2></td>";
                    
                    echo "</tr>";
                    
                    //-------------///
                    
                    echo "<tr>";
                    $queryFjobRelatedNo = "SELECT COUNT(*) AS count FROM employment_data WHERE first_job_related_cours='No'";
                    $resultFjobRelatedNo = $conn-> query($queryFjobRelatedNo);

                    while ($row = $resultFjobRelatedNo->fetch_assoc()) {

                    $resFjobRelatedNo = $row['count'];
                    echo "<td><h2>Number of Alumni that says Yes that the course they <br> took up in college is related to their first job: $resFjobRelatedNo</h2></td>";
                    }
                    
                    $sqlFjobRelatedNo = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni that says No that the course they took up in college is related to their first job'";
                    $result6 = mysqli_query($conn, $sqlFjobRelatedNo);
                    while($row=mysqli_fetch_array($result6)){
                        $postFjobRelatedNo=$row['num'];
                        echo "<td><h2>Chart(no): $postFjobRelatedNo</h2></td>";    
                    }
                    
                    $holdFjobRelatedNo = $resFjobRelatedNo - $postFjobRelatedNo;
                    echo "<td><h2>To be added on the chart: $holdFjobRelatedNo</h2></td>";
                    
                    echo "</tr>";
                    
                    //----------//
                    
                    echo "<tr>";
                    $queryCjobRelated = "SELECT COUNT(*) AS count FROM employment_data WHERE current_job_related='Yes'";
                    $resultCjobRelated = $conn-> query($queryCjobRelated);

                    while ($row = $resultCjobRelated->fetch_assoc()) {

                    $resCjobRelated = $row['count'];
                    echo "<td><h2>Number of Alumni that says Yes that the course they <br> took up in college is related to their current job: $resCjobRelated</h2></td>";
                    }
                    
                    $sqlCjobRelated = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni that says Yes that their current job is related to their course'";
                    $result7 = mysqli_query($conn, $sqlCjobRelated);
                    while($row=mysqli_fetch_array($result7)){
                        $postCjobRelated=$row['num'];
                        echo "<td><h2>Chart(Yes): $postCjobRelated</h2></td>";    
                    }
                    
                    $holdCjobRelated = $resCjobRelated - $postCjobRelated;
                    echo "<td><h2>To be added on the chart: $holdCjobRelated</h2></td>";
                    
                    echo "</tr>";
                    
                    //--------//
                    
                    
                    echo "<tr>";
                    $queryCjobRelatedNo = "SELECT COUNT(*) AS count FROM employment_data WHERE current_job_related='No'";
                    $resultCjobRelatedNo = $conn-> query($queryCjobRelatedNo);

                    while ($row = $resultCjobRelatedNo->fetch_assoc()) {

                    $resCjobRelatedNo = $row['count'];
                    echo "<td><h2>Number of Alumni that says Yes that the course they <br> took up in college is related to their current job: $resCjobRelatedNo</h2></td>";
                    }
                    
                    $sqlCjobRelatedNo = "SELECT name, SUM(number) AS num FROM reports WHERE name = 'Number of Alumni that says No that their current job is related to their course'";
                    $result8 = mysqli_query($conn, $sqlCjobRelatedNo);
                    while($row=mysqli_fetch_array($result8)){
                        $postCjobRelatedNo=$row['num'];
                        echo "<td><h2>Chart(no): $postCjobRelatedNo</h2></td>";    
                    }
                    
                    $holdCjobRelatedNo = $resCjobRelatedNo - $postCjobRelatedNo;
                    echo "<td><h2>To be added on the chart: $holdCjobRelatedNo</h2></td>";
                    
                    echo "</tr>";
                    
                    
                    
                    ?>
                    
                    
                    
                </table>
                
                <br>
                    <select name="UpdateName" style="height:20px; font-size:14px">
                        <option value="Number Of Alumni">Number Of Alumni</option>
                        <option value="Number Of Registered Alumni">Number Of Registered Alumni</option>
                        <option value="Number Of Employed Alumni">Number Of Employed Alumni</option>
                        <option value="Number Of Unemployed Alumni">Number Of Unemployed Alumni</option>
                        <option value="Number of Alumni that says Yes that the course they took up in college is related to their first job">First 
                        job Related to the course (yes)</option>
                        <option value="Number of Alumni that says No that the course they took up in college is related to their first job">First 
                        job Related to the course (no)</option>
                        
                        <option value="Number of Alumni that says Yes that their current job is related to their course">Current 
                        job Related to the course (Yes)</option>
                        <option value="Number of Alumni that says No that their current job is related to their course">Current 
                        job Related to the course (no)</option>


                    </select>
                <input type="text" name="UpdateNumber" style="height:20px; font-size:14px;">
                <br><br>
                <input type="submit" value="Update" name="UPDATE1">
                
                <?php
                    
                
                    if(isset($_POST['UPDATE1'])){
                        $UpdateName = $_POST['UpdateName'];
                        $UpdateNumber = $_POST['UpdateNumber'];

                        $query = "INSERT INTO reports (name, number) VALUES ('$UpdateName','$UpdateNumber')";
                        
                            if(mysqli_query($conn, $query)){
                                echo "<h2>Added Successfully!<h2>";
                                echo "<meta http-equiv='refresh' content='0'>";
                                
                            }
                            else{
                                echo mysqli_error();
                            }
                         
                        
                    }
                ?>
                
            </div>
            <br><br>
            <div class="panelAlumni">
                <b>Admin Account</b>
                <h2>Admin Registration Request: </h2>
                
                <table>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Alumni ID</th>
                    <th>Status</th>
                    
                    <?php
                    
                        $sql = "SELECT id, username, password, name, status FROM admin_account WHERE status = 'inactive'";
                        $result = $conn-> query($sql);

                        if($result-> num_rows > 0) {
                            while ($row = $result -> fetch_assoc()){
                                echo "<tr><td>". $row["id"] ."</td>
                                <td>" .$row["username"]. "</td>
                                <td>" .$row["password"]. "</td>
                                <td>" .$row["name"]. "</td>
                                <td>" .$row["status"]. "</td></tr>"; 
                            }
                            echo "</table>";
                        }
                        else{
                            echo "0 result";
                        }
                    ?>
                </table>
                <h2 style="font-size:14px;">Enter ID set to Active: <input type="text" name="setActAdmin" style="height:15px; font-size:14px;"> <h2>
                <input type="submit" name="UPDATEADMIN" value="Set Active"> <br><br><br>
                    
                <h2 >Admin Deactivate: </h2>
                <table>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Alumni ID</th>
                    <th>Status</th>
                    
                    <?php
                    
                        $sql = "SELECT id, username, password, name, status FROM admin_account WHERE status = 'active'";
                        $result = $conn-> query($sql);

                        if($result-> num_rows > 0) {
                            while ($row = $result -> fetch_assoc()){
                                echo "<tr><td>". $row["id"] ."</td>
                                <td>" .$row["username"]. "</td>
                                <td>" .$row["password"]. "</td>
                                <td>" .$row["name"]. "</td>
                                <td>" .$row["status"]. "</td></tr>"; 
                            }
                            echo "</table>";
                        }
                        else{
                            echo "0 result";
                        }
                    ?>
                </table>
                <h2 style="font-size:14px;">Enter ID set to Active: <input type="text" name="setInactAdmin" style="height:20px; font-size:14px;"> <h2>
                <input type="submit" name="UPDATEADMININACT" value="Set Inactive">
                    
            </div>
            
            <a href="index.php" style="bottom-right: 1000px;">Back to Home</a>
            <?php else: ?>
            <h3 style="color:black; text-align:center; font-size: 30px;">Please Login first</h3>
            <a href="index.php" style="bottom-right: 1000px; text-align:center; padding-left:500px;">Back to Home</a>
            <?php endif; ?>
        </form>
		</div>
        
        
            
	</body>
</html>