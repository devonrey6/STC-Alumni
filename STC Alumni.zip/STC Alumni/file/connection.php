<?php
    $conn = mysqli_connect("localhost",'root','','thesis');

    if(mysqli_connect_errno()){
        echo "Could not connect to Database";
        
    }
?>