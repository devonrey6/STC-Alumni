<?php
    include "connection.php";
    session_start();

    if(isset($_POST['UPDATE2'])){
        $active = 'active';
        $alumniID = $_POST['setAct'];
        
        $queryInact = "UPDATE alumni_account SET status = 'active' WHERE id = $alumniID";
        
        if(mysqli_query($conn, $queryInact)){
            header("location: admininfo.php");
        }
        else{
            echo mysqli_error();
        }
    }
?>


<html>
	<head>
		<title>Admin</title>
        
        <style>
            #nav1 h1{
                float: left;
                font-size: 2.5em;
                margin-left: 15px;
                padding-left: 30px;
            }
            #nav1 h1 a{
                text-decoration: none;
                color: white;
            }
            #nav1 ul{
                float: right;
                margin-right: 15px;
            }
            #nav1 ul li{
                display: inline-block;
                list-style-type: none;

            }
            #nav1 ul li a{
                text-decoration: none;
                color: black;
                padding: 25px;
            }
            #nav1 ul li:hover{
                background: #a09e9e;
                transition: all ease-in-out 0.45s;
            }
            table {
                border-collapse: collapse;
                width: 70%;
                color: black;
                font-family: sans-serif;
                font-size: 12px;
                text-align: left;
            }
            th{
                background-color: #800000;
                color: white;
                width: 10%
            }
            body{
                background-color: #800000;
            }
            hr{
                color: #800000;
            }
            td{
                color: orangered;
            }
        </style>
        
		
        <link href="css/admin.css" rel="stylesheet" type="text/css">
	</head>
	
	<body background="back.png" style="background-color: #800000">
		<div class="loginbox" style="height: 600px; width: 1100px; overflow:auto;  ">
		
		<?php if(isset($_SESSION['usernameAdmin'])): ?>
            
		<form action="admininfo.php" method="post">
            
            <div id="nav1">
                
                <ul>
                    
                    <?php 
                        $queryNumAlum = "SELECT COUNT(*) AS count FROM alumni_account WHERE status = 'inactive'";
                        $resultNumAlum = $conn-> query($queryNumAlum);

                        while ($row = $resultNumAlum->fetch_assoc()) {

                        $resNumAlum = $row['count'];
                            echo '<li id="active"><a href="adminacc.php" style="font-size:15px;"> Admin Account</a></li>';
                            if($resNumAlum > 0) {
                                echo '<li><a href="admininfo.php" style="color:red; font-size:15px;"> Information Notification/Report ('.$resNumAlum.')</a></li>';
                            }
                            else {
                                echo '<li><a href="admininfo.php" style="font-size:15px;"> Information Notification/Report ('.$resNumAlum.')</a></li>';
                            }
                            echo '<li><a href="adminannc.php" style="font-size:15px;"> Announcement and School Update</a></li>';
                            echo '<li><a href="admingrad.php" style="font-size:15px;"> Graduate List</a></li>';
                            echo '<li><a href="logout.php" style="font-size:15px;"> Logout</a></li>';
                        }
                    ?>
                    
                    
                </ul>
		    </div>
            
            <br><br><br><br><br>
            
            <div class="panel2">
                <b>Information Notification/Reports</b>
                <h2>Alumni Registration Request: </h2>
                
                <table border="1" frame="hsides" rules="rows" style="font-size:14px;">
                    <th>ID</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Alumni ID</th>
                    <th>Status</th>
                    
                    <?php
                    
                        $sql = "SELECT id, username, password, alumni_id, status FROM alumni_account WHERE status = 'inactive'";
                        $result = $conn-> query($sql);

                        if($result-> num_rows > 0) {
                            while ($row = $result -> fetch_assoc()){
                                echo "<tr><td>". $row["id"] ."</td>
                                <td>" .$row["username"]. "</td>
                                <td>" .$row["password"]. "</td>
                                <td>" .$row["alumni_id"]. "</td>
                                <td>" .$row["status"]. "</td></tr>"; 
                            }
                            echo "</table>";
                        }
                        else{
                            echo "0 result";
                        }
                    ?>
                </table>
                <h2 style="font-size:14px;">Enter ID set to Active: <input type="text" name="setAct" style="height:20px; font-size:14px;"> <h2>
                <input type="submit" name="UPDATE2" value="Set Active">
            </div>
            
            <a href="index.php" style="bottom-right: 1000px;">Back to Home</a>
            
            <?php else: ?>
            <h3 style="color:black; text-align:center; font-size: 30px;">Please Login first</h3>
            <a href="index.php" style="bottom-right: 1000px; text-align:center; padding-left:500px;">Back to Home</a>
            <?php endif; ?>        
            
        </form>
		</div>
        
        
            
	</body>
</html>