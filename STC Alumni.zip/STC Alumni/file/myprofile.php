<?php
    ini_set('mysql.connect_timeout', 300);
    ini_set('default_socket_timeout', 300);
    include "connection.php";
    session_start();
    
?>
<html>
	<head>
		<title>Admin</title>
		<link href="css/user.css" rel="stylesheet" type="text/css">
	</head>
	
	<body >
		<div class="loginbox" style="height: 650px; width: 980px;  ">
		<img src="images/avatar.png" class="avatar">
        <?php if(isset($_SESSION['username'])): ?>
        <?php if(isset($_SESSION['username'])): ?>
		<h1>Welcome: <?php echo $_SESSION['username']; ?></h1>
        <?php endif;?>
		<form method="post" action="myprofile.php" enctype="multipart/form-data">
            <div class="panel1">
                <?php if(isset($_SESSION['username'])): ?>
                <b>Username: <?php echo $_SESSION['username']; ?></b>
                <?php endif;?>
                <br>
                <b>
                ID: <?php
                $postname = $_SESSION['username'];
                $sqlViewText = "SELECT id FROM alumni_account WHERE username = '$postname'";
                $result = mysqli_query($conn, $sqlViewText);
                while($row=mysqli_fetch_array($result)){
                ?>
                <?php echo $postid=$row['id']?>
                    
                <?php
                }
                    ?> </b>
                <br>
            </div>
            <?php
                $sql = "SELECT fname, lname, mname, address1, address2, email, contact_number, mobile_number, civil_status, gender, birthday, region_of_origin, province, residence FROM alumni_generalinfo WHERE alumni_account_id = '$postid'";
                $result = $conn-> query($sql);
            
                function displayimage()
                {
                    include "connection.php";
                    $name = $_SESSION['username'];
                    $query = "SELECT * FROM images WHERE username='$name'";
                    $result1 = mysqli_query($conn, $query);
                    while($row = mysqli_fetch_array($result1))
                    {
                        echo '<img height="50" width="50" src="data:image;base64,'.$row['2'].'">';
                    }
                    mysqli_close($conn);
                }
            ?>
            <br>
            
            <table>
                <?php
                    displayimage();
                    if($result-> num_rows > 0) {
                            while ($row = $result -> fetch_assoc()){
                                echo "<tr>";
                                echo "<td>First Name:</td>";
                                echo "<td>" .$row["fname"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Last Name:</td>";
                                echo "<td>" .$row["lname"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Middle Name:</td>";
                                echo "<td>" .$row["mname"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Address 1:</td>";
                                echo "<td>" .$row["address1"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Address 2:</td>";
                                echo "<td>" .$row["address2"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Email:</td>";
                                echo "<td>" .$row["email"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Contact Number:</td>";
                                echo "<td>" .$row["contact_number"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Mobile Number:</td>";
                                echo "<td>" .$row["mobile_number"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Civil Status:</td>";
                                echo "<td>" .$row["civil_status"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Gender:</td>";
                                echo "<td>" .$row["gender"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Birthday:</td>";
                                echo "<td>" .$row["birthday"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Region of Origin:</td>";
                                echo "<td>" .$row["region_of_origin"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Province:</td>";
                                echo "<td>" .$row["province"]. "</td>";
                                echo "</tr>";
                                
                                echo "<tr>";
                                echo "<td>Residence:</td>";
                                echo "<td>" .$row["residence"]. "</td>";
                                echo "</tr>";
                            }
                            
                        }
                
                
                ?>
                
                
            </table>
            <br><br><br>
            <a href="user.php">Back to User Account</a><br>
            <?php else: ?>
            <h2 style="color:black">Please Login first</h2>
            <?php endif; ?>
            <a href="index.php">Back to Home</a>
        </form>
		</div>
        
        
            
	</body>
</html>