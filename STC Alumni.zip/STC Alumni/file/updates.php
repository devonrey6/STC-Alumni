<?php
    session_start();
    include 'connection.php';

    function displayimage()
        {
            include "connection.php";
            $name = $_SESSION['username'];
            $query = "SELECT * FROM image_post_update";
            $result1 = mysqli_query($conn, $query);
            while($row = mysqli_fetch_array($result1))
            {
                echo '<img height="100" width="100" src="data:image;base64,'.$row['4'].'">';
                
            }
            mysqli_close($conn);
        }
?>

<html>
	<head>
		<title>Updates</title>
        <style>
            table {
                border-collapse: collapse;
                width: 100%;
                color: black;
                font-family: sans-serif;
                font-size: 12px;
                text-align: left;
            }
            th{
                background-color: #800000;
                color: white;
                width: 10%;
                font-size: 15px;
            }
            
        </style>
		<link href="css/updates.css" rel="stylesheet" type="text/css">
	</head>
	
	<body >
		<div class="loginbox" style="overflow:auto;">
		
		<h1 style="padding-bottom: 10px;">Updates</h1>
            
            <?php if(isset($_SESSION['username'])): ?>
            
            <div style="line-height:5px; font-size: 10px; color:black;">
                
                    
                    <table style="line-height:7px; font-size: 10px; color:black;" >
                    <?php
                        
                        $sqlView1 = "SELECT date, post, image FROM image_post_update";
                        $result1 = $conn-> query($sqlView1);

                        if($result1-> num_rows > 0) {
                            while ($row1 = $result1 -> fetch_assoc()){
                                echo "<tr><td><h3 style='font-size:14px;'>Date: ".$row1['date']."</h3></td></tr>";
                                echo "<tr><td><h3 style='font-size:14px;'>Announcement: ".$row1['post']."</h3></td></tr>";
                                
                                echo '<tr><td><img height="150" width="300" src="data:image;base64,'.$row1['image'].'"></td></tr><br>';
                                
                                
                            }
                            echo "</table>";
                        }
                        else{
                            echo "0 result";
                        }
                    ?>
                    </table>
                
            </div>
                
            <?php else: ?>
            <h1>Please Login first</h1>
            <?php endif; ?>
		<form>
			<br><br><br>
            <a href="index.php">Back to Home</a>
		<form>
		</div>
	</body>
</html>