<?php
    include "connection.php";
    session_start();
    if(isset($_POST['submit'])){
        $user = $_POST['username'];
        $pass = $_POST['password'];
        
        $query = "SELECT * FROM admin_account WHERE username = '$user' AND password = '$pass' AND status = 'active';";
        
        $run = mysqli_query ($conn, $query);
        if(mysqli_num_rows($run)>0){
            echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
            header("location: adminacc.php");
            $_SESSION['usernameAdmin'] = $user;
        }else{
            echo "<script type='text/javascript'>alert('Username and Password Incorrect.. If you have already registered please wait for the confirmation of your account!')</script>";
        }
    }

?>
<html>
	<head>
		<title>Administrator Login</title>
		<link href="css/login.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>
		<div class="loginbox">
		<img src="images/avatar.png" class="avatar">
		<h1>Administrator Login</h1>
		<form action="loginAdmin.php" method="post">
			<p>Username</p>
			<input type="text" name="username" placeholder="Enter Username" required>
			<p>Password</p>
			<input type="password" name="password" placeholder="Enter Password" required>
			<input type="submit" name="submit" value="Login">
            <br><br><br><br>
            <a href="index.php">Back to Home</a>
            
		<form>
		</div>
	</body>
</html>