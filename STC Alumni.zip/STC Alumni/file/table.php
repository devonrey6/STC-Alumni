<?php
    include "connection.php";

    if(isset($_POST['search'])){

        $valueToSearch = $_POST['valueToSearch'];
        $searchType = $_POST['searchType'];
        
        $query = "SELECT name, gender, bdate, bplace, present_add, degree, contact, email, department, year_grad FROM graduate_list WHERE $searchType = '$valueToSearch'";
        $search_result = filterTable($query);
        
    }else{
        $query = "SELECT * FROM `graduate_list`";
        $search_result = filterTable($query);
    }


    function filterTable($query){
        include "connection.php";
        $filter_Result = mysqli_query($conn, $query);
        return $filter_Result;
    }


?>



<html>
    <head>
        <title></title>
        <style>
            table,tr,th,td{
                border: 1px solid black;
            }
        </style>
    </head>
    
    <body>
        <form action="table.php" method="post">
            <br>
            <select name="searchType">
                        <option value="department">Department</option>
                        <option value="year_grad">Year Graduated</option>
                    </select>
            <input type="text" name="valueToSearch" placeholder="Value To Search">
            <input type="submit" name="search" value="Filter"> <br> <br>
            
            <table>
                <tr>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Birthdate</th>
                    <th>Birthplace</th>
                    <th>Present Address</th>
                    <th>Degree</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Year Graduated</th>
                </tr>
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['gender'];?></td>
                    <td><?php echo $row['bdate'];?></td>
                    <td><?php echo $row['bplace'];?></td>
                    <td><?php echo $row['present_add'];?></td>
                    <td><?php echo $row['degree'];?></td>
                    <td><?php echo $row['contact'];?></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['department'];?></td>
                    <td><?php echo $row['year_grad'];?></td>
                    
                </tr>
                <?php endwhile;?>
            </table>
        </form>
        
    </body>
</html>