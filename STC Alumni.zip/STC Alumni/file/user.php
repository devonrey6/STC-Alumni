<?php
    session_start();
    ini_set('mysql.connect_timeout', 300);
    ini_set('default_socket_timeout', 300);
    include "connection.php";
    
    
    function saveimage($name, $image) 
        {
            include "connection.php";
            $username = $_SESSION['username'];
            $query = "INSERT INTO images (name, image, username) VALUES ('$name','$image', '$username')";
            $result = mysqli_query($conn, $query);
            if($result)
            {
                echo "<br/> Image uploaded";
            }
                else{
                echo "<br/> Image not uploaded";
            }
        }
?>
<html>
	<head>
		<title>User</title>
		<link href="css/user.css" rel="stylesheet" type="text/css">
	</head>
	
	<body >
		<div class="loginbox">
		<img src="images/avatar.png" class="avatar">
        <?php if(isset($_SESSION['username'])): ?>
        <?php if(isset($_SESSION['username'])): ?>
		<h1>Welcome: <?php echo $_SESSION['username']; ?></h1>
        <?php endif;?>
		<form method="post" enctype="multipart/form-data">
            <div class="panel1">
                <?php if(isset($_SESSION['username'])): ?>
                <b>Username: <?php echo $_SESSION['username']; ?></b>
                <?php endif;?>
                <br>
            </div>
            <br>
            <div class="panel2">
                <b style="font-size:14px;"><a href="chedform.php">CHED Form (Please fill up this form to complete your profile)</a></b>
            </div>
            
            <div class="panel3">
                <b style="font-size:14px;">Upload Profile Photo: <input type="file" name="image" accept="image/*" ><input type="submit" name="submit" value="Upload"></b>
                <?php
                    if(isset($_POST['submit']))
                    {
                        if(getimagesize($_FILES['image']['tmp_name'])== FALSE)
                        {
                            echo "Please select an image. ";
                        }
                        else
                        {
                            $image = addslashes($_FILES['image']['tmp_name']);
                            $name = addslashes($_FILES['image']['name']);
                            $image = file_get_contents($image);
                            $image = base64_encode($image);
                            saveimage($name, $image);
                        }
                    }
                    
                ?>
            </div>
            
            <div class="panel4">
                <b style="font-size:14px;">Go to: <a href="myprofile.php">My Profile account</a></b>
            </div>
            
            <?php else: ?>
            <h2 style="color:black">Please Login first</h2>
            <?php endif; ?>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <a href="index.php">Back to Home</a>
            
        </form>
		</div>
        
        
            
	</body>
</html>