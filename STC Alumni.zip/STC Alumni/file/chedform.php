<?php
    include "connection.php";
    session_start();
    
    if(isset($_POST['submitall'])){
        
            $trapx = $_POST['trap'];
        
        
        
            $check = mysqli_query($conn, "SELECT * FROM alumni_generalinfo WHERE alumni_account_id='$trapx'");
            $checkrows = mysqli_num_rows($check);
            
            if($checkrows>0){
                echo "<script type='text/javascript'>alert('You already finished this survey')</script>";
            }
            else{
                
                $fname = $_POST['fname'];
                $lname = $_POST['lname'];
                $mname = $_POST['mname'];
                $address1 = $_POST['address1'];
                $address2 = $_POST['address2'];
                $email = $_POST['email'];
                $cnumber = $_POST['cnumber'];
                $mnumber = $_POST['mnumber'];
                $civil = $_POST['civil'];
                $gender = $_POST['gender'];
                $bdate = $_POST['date'];
                $region = $_POST['region'];
                $province = $_POST['province'];
                $location = $_POST['location'];
                $username = $_SESSION['username'];
                $quer = "SELECT id FROM alumni_account WHERE username = '$username'";
                $result = $conn-> query($quer);

                while ($row = $result->fetch_assoc()) {

                    $res = $row['id'];
                    $query1 = "INSERT INTO alumni_generalinfo (fname, lname, mname, address1, address2, email, contact_number, mobile_number, civil_status, gender, birthday, region_of_origin, province, residence, alumni_account_id) VALUES('$fname','$lname','$mname', '$address1', '$address2', '$email', '$cnumber', '$mnumber', '$civil', '$gender', '$bdate', '$region', '$province', '$location', '$res')";

                    if(mysqli_query($conn, $query1)){
                        header("location: chedform.php");
                    }
                    else{
                        echo mysqli_error();
                    }

                }


                $degree1 = $_POST['degree1'];
                $degree2 = $_POST['degree2'];
                $degree3 = $_POST['degree3'];
                $degree4 = $_POST['degree4'];
                $degree5 = $_POST['degree5'];
                $college1 = $_POST['college1'];
                $college2 = $_POST['college2'];
                $college3 = $_POST['college3'];
                $college4 = $_POST['college4'];
                $college5 = $_POST['college5'];
                $year1 = $_POST['year1'];
                $year2 = $_POST['year2'];
                $year3 = $_POST['year3'];
                $year4 = $_POST['year4'];
                $year5 = $_POST['year5'];
                $honor1 = $_POST['honor1'];
                $honor2 = $_POST['honor2'];
                $honor3 = $_POST['honor3'];
                $honor4 = $_POST['honor4'];
                $honor5 = $_POST['honor5'];
                $exam1 = $_POST['exam1'];
                $exam2 = $_POST['exam2'];
                $exam3 = $_POST['exam3'];
                $date1 = $_POST['date1'];
                $date2 = $_POST['date2'];
                $date3 = $_POST['date3'];
                $rate1 = $_POST['rate1'];
                $rate2 = $_POST['rate2'];
                $rate3 = $_POST['rate3'];

                $conDegree = $degree1 . $degree2 . $degree3. $degree4 . $degree5;
                $conCollege = $college1 . $college2 . $college3 . $college4 . $college5;
                $conYear = $year1 . $year2 . $year3 . $year4 . $year5;
                $conHonor = $honor1 . $honor2 . $honor3 . $honor4 . $honor5;
                $conExam = $exam1 . $exam2 . $exam3;
                $conDate = $date1 . $date2 . $date3;
                $conRate = $rate1 . $rate2 . $rate3;

                $question1 = $_POST['question1'];
                $question2 = $_POST['question2'];
                $question3 = $_POST['question3'];
                $question4 = $_POST['question4'];
                $question5 = $_POST['question5'];
                $question6 = $_POST['question6'];
                $question7 = $_POST['question7'];
                $question8 = $_POST['question8'];
                $question9 = $_POST['question9'];
                $question10 = $_POST['question10'];
                $question11 = $_POST['question11'];
                $question12 = $_POST['question12'];
                $question13 = $_POST['question13'];
                $question14 = $_POST['question14'];
                $questionSpec = $_POST['questionSpec'];

                $query2 = "INSERT INTO alumni_educationalback (degree, college_university, year_grad, honor, name_of_examination, date_taken, rating, 14_1, 14_2, 14_3, 14_4, 14_5, 14_6, 14_7, 14_8, 14_9, 14_10, 14_11, 14_12, 14_13, 14_14, 14_specify) Values ('$conDegree', '$conCollege', '$conYear', '$conHonor', '$conExam', '$conDate', '$conRate', '$question1', '$question2', '$question3', '$question4', '$question5', '$question6', '$question7', '$question8', '$question9', '$question10', '$question11', '$question12', '$question13', '$question14', '$questionSpec' )";

                if(mysqli_query($conn, $query2)){
                    header("location: chedform.php");
                }
                else{
                    echo mysqli_error();
                }

                $training1 = $_POST['training1'];
                $training2 = $_POST['training2'];
                $training3 = $_POST['training3'];
                $duration1 = $_POST['duration1'];
                $duration2 = $_POST['duration2'];
                $duration3 = $_POST['duration3'];
                $nameTraining1 = $_POST['nameTraining1'];
                $nameTraining2 = $_POST['nameTraining2'];
                $nameTraining3 = $_POST['nameTraining3'];

                $conTraining = $training1 . $training2 . $training3;
                $conDuration = $duration1 . $duration2 . $duration3;
                $conNameTrain = $nameTraining1 . $nameTraining2 . $nameTraining3;

                $query3 = "INSERT INTO training_advance_studies_attended (title_of_training, duration_credits_earned, name_training_college) VALUES ('$conTraining', '$conDuration', '$conNameTrain')";

                if(mysqli_query($conn, $query3)){
                    header("location: chedform.php");
                }
                else{
                    echo mysqli_error();
                }

                $employed = $_POST['employed'];
                $res = $_POST['res'];
                $empstatus = $_POST['empstatus'];
                $occupation = $_POST['occupation'];
                $companyOrg = $_POST['companyOrg'];
                $majorline = $_POST['majorline'];
                $placeWork = $_POST['placeWork'];
                $fjob = $_POST['fjob'];
                $sjob = $_POST['sjob'];
                $relatedJob = $_POST['relatedJob'];
                $acceptJob = $_POST['acceptJob'];
                $changeJob = $_POST['changeJob'];
                $longStay = $_POST['longStay'];
                $findfjob = $_POST['findfjob'];
                $landfjob = $_POST['landfjob'];
                $rcle = $_POST['rcle'];
                $pts = $_POST['pts'];
                $me = $_POST['me'];
                $selfemp = $_POST['selfemp'];
                $gross = $_POST['gross'];
                $relevantfjob = $_POST['relevantfjob'];
                $usefjob = $_POST['usefjob'];
                $currentjob = $_POST['currentjob'];
                $suggest = $_POST['suggest'];

                $query4 = "INSERT INTO employment_data (present_employed, reason_not_employed, present_employment_status, present_occupation, name_of_company, major_line_business, place_of_work, first_job_college, reason_stay_job, first_job_related_cours, reason_accepting_job, reason_changing_job, stay_long_first_job, find_long_first_job, take_long_first_job, rank_clerical, technical_supervisory, managerial_executive, self_employed, gross_income_monthly, curriculum_relevant_first_job, competencies_learned_useful, current_job_related, suggestion) 
                VALUES ('$employed', '$res', '$empstatus', '$occupation', '$companyOrg', '$majorline', '$placeWork', '$fjob', '$sjob', '$relatedJob', '$acceptJob', '$changeJob', '$longStay', '$findfjob', '$landfjob', '$rcle', '$pts', '$me', '$selfemp', '$gross', '$relevantfjob', '$usefjob', '$currentjob','$suggest')";

                if(mysqli_query($conn, $query4)){
                    header("location: chedform.php");
                }
                else{
                    echo mysqli_error();
                }
        
            
        
            }
            
            
 
        
    }
    
?>

<html>
	<head><title>CHED FORM</title>
    <link href="css/ched.css" rel="stylesheet" type="text/css">    
    <head>
	
	<body>
		<form action="chedform.php" method="post" id="form">
            <img src="images/ched.png"> <br>
            
			REPUBLIC OF THE PHILIPPINES <br>
            OFFICE OF THE PRESIDENT <br>
            Commission on Higher Education <br>
            Caraga Administrative Region <br><br><br>
            
            ID: <?php
            $user1 = $_SESSION['username'];
            $querytrap = "SELECT id FROM alumni_account WHERE username = '$user1'";
            $resulttrap = $conn-> query($querytrap);
        
            while ($row = $resulttrap->fetch_assoc()) {
            
            $ress = $row['id'];
            echo "<input type ='text' value='$ress' name='trap'>";
            
            
            }
            
            ?> 
            
            
            
            Control Code: <?php
            $sqlViewText = "SELECT COUNT(id) AS number FROM alumni_generalinfo";
            $result = mysqli_query($conn, $sqlViewText);
            while($row=mysqli_fetch_array($result)){
            ?>
            <input type="text" name="controlid" value="<?php echo $row['number']?>">
            <?php
            }
            ?>
            <br> <br>
            
            Dear Graduates: <br> <br>
            Good day! Please complete this GTS questionnaire as accurately & frankly as <br>possible by checking (/) 
            the box corresponding to your response. Your answer will <br>be used for research purposes 
            in order to assess graduate employability and <br>eventually, improve course offerings of your alma mater 
            & other universities/colleges <br>in the Philippines. Your answers to this survey will be treated with strictest confidentiality.
            <br><br>
            <a> <b>GRADUATE TRACER SURVEY (GTS)</b><a>
                
                <ol type="A">
                    <li><b>General Information</b>
                        <ol>
                            <table border="0">
                                
                                <tr>
                                    <td><li>First Name </li></td>
                                    <td><input type="text" name="fname" required></td>
                                </tr>
                                <tr>
                                    <td><li>Last Name </li></td>
                                    <td><input type="text" name="lname" required></td>
                                </tr>
                                <tr>
                                    <td><li>Middle Name </li></td>
                                    <td><input type="text" name="mname" required></td>
                                </tr>
                                 <tr>
                                    <td><li>Address 1</li> </li></td>
                                    <td><input type="text" name="address1" required></td>
                                </tr>
                                <tr>
                                    <td><li>Address 2</li> </li></td>
                                    <td><input type="text" name="address2" required></td>
                                </tr>
                                 <tr>
                                    <td><li>Email Address </li></td>
                                    <td><input type="email" name="email" required></td>
                                </tr>
                                 <tr>
                                    <td><li>Telephone or Contact Number</li></td>
                                    <td><input type="text" name="cnumber" onkeypress="isInputNumber(event)" required></td>
                                </tr>
                                 <tr>
                                    <td><li>Mobile Number</li></td>
                                    <td><input type="text" name="mnumber" maxlength="11" onkeypress="isInputNumber(event)" required></td>
                                </tr>
                
                                <script>
                
                                    function isInputNumber(evt) {
                                        var ch = String.fromCharCode(evt.which);

                                        if(!(/[0-9]/.test(ch))) {
                                            evt.preventDefault();
                                        }

                                    }

                                </script>
                
                                 <tr>
                                    <td><li>Civil Status</li></td>
                                     
                                    <td><input type="radio" name="civil" value="Single" checked> Single
                                    <input type="radio" name="civil" value="Separated"> Seperated/Divorce </td>
                                     
                                    <td><input type="radio" name="civil" value="SingleParent"> Single Parent
                                    <input type="radio" name="civil" value="Married"> Married </td>
                                     
                                    <td><input type="radio" name="civil" value="Marriednotlive"> Married but not living with spouse
                                    <input type="radio" name="civil" value="Widow"> Widow/Widower </td>
                                     
                                </tr>
                                 <tr>
                                    <td><li>Sex</li></td>
                                    <td><input type="radio" name="gender" value="male" checked> Male
                                        <input type="radio" name="gender" value="female"> female   </td>
                                </tr>
                                 <tr>
                                    <td><li>Birthday</li></td>
                                    <td><input type="date" name="date" required></td>
                                </tr>
                                 <tr>
                                    <td><li>Region of Origin</li></td>
                                    <td><select name="region">
                                        <option value="Region 1">Region 1</option>
                                        <option value="Region 2">Region 2</option>
                                        <option value="Region 3">Region 3</option>
                                        <option value="Region 4">Region 4</option>
                                        <option value="Region 5">Region 5</option>
                                        <option value="Region 6">Region 6</option>
                                        <option value="Region 7">Region 7</option>
                                        <option value="Region 8">Region 8</option>
                                        <option value="Region 9">Region 9</option>
                                        <option value="Region 10">Region 10</option>
                                        <option value="Region 11">Region 11</option>
                                        <option value="Region 12">Region 12</option>
                                        <option value="NCR">NCR</option>
                                        <option value="CAR">CAR</option>
                                        <option value="ARMM">ARMM</option>
                                        <option value="CARAGA">CARAGA</option>
                                    </select></td>
                                </tr>
                                 <tr>
                                    <td><li>Province</li></td>
                                    <td><input type="text" name="province" required></td>
                                </tr>
                                 <tr>
                                    <td><li>Location of Residence</li></td>
                                    <td><input type="radio" name="location" value="City" checked> City
                                        <input type="radio" name="location" value="Municipality"> Municipality   </td>
                                </tr>
                            </table>

                            
                        </ol>
                    </li>
                        
            <li><b>Education Background</b>
                                <ol start="15">
                                    <li>Educational Attainment (Baccalaureate Degree Only)</li>
                                </ol>
                                
                                <table border="1">
                                    <tr>
                                        <td align="center">Degree(s) & Specialization</td>
                                        <td align="center">College or University</td>
                                        <td align="center">Year Graduated</td>
                                        <td align="center">Honor</td>
                                    </tr>
                                    <tr>
                                        <td align="center">
                                        <select name="degree1">
                                        <option value="Master of Arts in Education (MAED)">Master of Arts in Education (MAED)</option>
                                        <option value="Major: Education Administration">Major: Education Administration</option>
                                        <option value="Master in Business Administration (MBA)">Master in Business Administration (MBA)</option>
                                        <option value="Bachelor of Arts in English Language">Bachelor of Arts in English Language</option>
                                        <option value="Bachelor of Arts in Political Science">Bachelor of Arts in Political Science</option>
                                        <option value="Bachelor of Science in Mathematics">Bachelor of Science in Mathematics</option>
                                        <option value="Bachelor of Science in Biology">Bachelor of Science in Biology</option>
                                        <option value="Bachelor of Elementary Education (BSEEd)">Bachelor of Elementary Education (BSEEd)</option>
                                        <option value="Bachelor of Secondary Education (BSEd)">Bachelor of Secondary Education (BSEd)</option>
                                        <option value="Bachelor of Science in Accountancy (BSA)">Bachelor of Science in Accountancy (BSA)</option>
                                        <option value="Bachelor of Science in Accounting Information System (BSAIS)">Bachelor of Science in Accounting Information System (BSAIS)</option>
                                        <option value="Bachelor of Science in Business Administration (BSBA)">Bachelor of Science in Business Administration (BSBA)</option>
                                        <option value="Bachelor of Science in Office Administration (BSOA)">Bachelor of Science in Office Administration (BSOA)</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Tourism Management (BSTM)">Bachelor of Science in Tourism Management (BSTM)</option>
                                        <option value="Bachelor of Science in Hospitality Management">Bachelor of Science in Hospitality Management</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Information Technology (BSIT)">Bachelor of Science in Information Technology (BSIT)</option>
                                        <option value="Bachelor of Science in Criminology (BSCrim)">Bachelor of Science in Criminology (BSCrim)</option>
                                            
                                        </select></td>
                                        <td><input type="text" name="college1" required></td>
                                        <td><input type="date" name="year1" required></td>
                                        <td><input type="text" name="honor1" required></td>
                                    </tr>
                                    <tr>
                                        <td align="center"><select name="degree2">
                                        <option value="Master of Arts in Education (MAED)">Master of Arts in Education (MAED)</option>
                                        <option value="Major: Education Administration">Major: Education Administration</option>
                                        <option value="Master in Business Administration (MBA)">Master in Business Administration (MBA)</option>
                                        <option value="Bachelor of Arts in English Language">Bachelor of Arts in English Language</option>
                                        <option value="Bachelor of Arts in Political Science">Bachelor of Arts in Political Science</option>
                                        <option value="Bachelor of Science in Mathematics">Bachelor of Science in Mathematics</option>
                                        <option value="Bachelor of Science in Biology">Bachelor of Science in Biology</option>
                                        <option value="Bachelor of Elementary Education (BSEEd)">Bachelor of Elementary Education (BSEEd)</option>
                                        <option value="Bachelor of Secondary Education (BSEd)">Bachelor of Secondary Education (BSEd)</option>
                                        <option value="Bachelor of Science in Accountancy (BSA)">Bachelor of Science in Accountancy (BSA)</option>
                                        <option value="Bachelor of Science in Accounting Information System (BSAIS)">Bachelor of Science in Accounting Information System (BSAIS)</option>
                                        <option value="Bachelor of Science in Business Administration (BSBA)">Bachelor of Science in Business Administration (BSBA)</option>
                                        <option value="Bachelor of Science in Office Administration (BSOA)">Bachelor of Science in Office Administration (BSOA)</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Tourism Management (BSTM)">Bachelor of Science in Tourism Management (BSTM)</option>
                                        <option value="Bachelor of Science in Hospitality Management">Bachelor of Science in Hospitality Management</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Information Technology (BSIT)">Bachelor of Science in Information Technology (BSIT)</option>
                                        <option value="Bachelor of Science in Criminology (BSCrim)">Bachelor of Science in Criminology (BSCrim)</option>
                                            
                                        </select></td>
                                        <td><input type="text" name="college2"></td>
                                        <td><input type="date" name="year2"></td>
                                        <td><input type="text" name="honor2"></td>
                                    </tr>
                                    <tr>
                                        <td align="center"><select name="degree3">
                                        <option value="Master of Arts in Education (MAED)">Master of Arts in Education (MAED)</option>
                                        <option value="Major: Education Administration">Major: Education Administration</option>
                                        <option value="Master in Business Administration (MBA)">Master in Business Administration (MBA)</option>
                                        <option value="Bachelor of Arts in English Language">Bachelor of Arts in English Language</option>
                                        <option value="Bachelor of Arts in Political Science">Bachelor of Arts in Political Science</option>
                                        <option value="Bachelor of Science in Mathematics">Bachelor of Science in Mathematics</option>
                                        <option value="Bachelor of Science in Biology">Bachelor of Science in Biology</option>
                                        <option value="Bachelor of Elementary Education (BSEEd)">Bachelor of Elementary Education (BSEEd)</option>
                                        <option value="Bachelor of Secondary Education (BSEd)">Bachelor of Secondary Education (BSEd)</option>
                                        <option value="Bachelor of Science in Accountancy (BSA)">Bachelor of Science in Accountancy (BSA)</option>
                                        <option value="Bachelor of Science in Accounting Information System (BSAIS)">Bachelor of Science in Accounting Information System (BSAIS)</option>
                                        <option value="Bachelor of Science in Business Administration (BSBA)">Bachelor of Science in Business Administration (BSBA)</option>
                                        <option value="Bachelor of Science in Office Administration (BSOA)">Bachelor of Science in Office Administration (BSOA)</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Tourism Management (BSTM)">Bachelor of Science in Tourism Management (BSTM)</option>
                                        <option value="Bachelor of Science in Hospitality Management">Bachelor of Science in Hospitality Management</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Information Technology (BSIT)">Bachelor of Science in Information Technology (BSIT)</option>
                                        <option value="Bachelor of Science in Criminology (BSCrim)">Bachelor of Science in Criminology (BSCrim)</option>
                                            
                                        </select></td>
                                        <td><input type="text" name="college3"></td>
                                        <td><input type="date" name="year3"></td>
                                        <td><input type="text" name="honor3"></td>
                                    </tr>
                                    <tr>
                                        <td align="center"><select name="degree4">
                                        <option value="Master of Arts in Education (MAED)">Master of Arts in Education (MAED)</option>
                                        <option value="Major: Education Administration">Major: Education Administration</option>
                                        <option value="Master in Business Administration (MBA)">Master in Business Administration (MBA)</option>
                                        <option value="Bachelor of Arts in English Language">Bachelor of Arts in English Language</option>
                                        <option value="Bachelor of Arts in Political Science">Bachelor of Arts in Political Science</option>
                                        <option value="Bachelor of Science in Mathematics">Bachelor of Science in Mathematics</option>
                                        <option value="Bachelor of Science in Biology">Bachelor of Science in Biology</option>
                                        <option value="Bachelor of Elementary Education (BSEEd)">Bachelor of Elementary Education (BSEEd)</option>
                                        <option value="Bachelor of Secondary Education (BSEd)">Bachelor of Secondary Education (BSEd)</option>
                                        <option value="Bachelor of Science in Accountancy (BSA)">Bachelor of Science in Accountancy (BSA)</option>
                                        <option value="Bachelor of Science in Accounting Information System (BSAIS)">Bachelor of Science in Accounting Information System (BSAIS)</option>
                                        <option value="Bachelor of Science in Business Administration (BSBA)">Bachelor of Science in Business Administration (BSBA)</option>
                                        <option value="Bachelor of Science in Office Administration (BSOA)">Bachelor of Science in Office Administration (BSOA)</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Tourism Management (BSTM)">Bachelor of Science in Tourism Management (BSTM)</option>
                                        <option value="Bachelor of Science in Hospitality Management">Bachelor of Science in Hospitality Management</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Information Technology (BSIT)">Bachelor of Science in Information Technology (BSIT)</option>
                                        <option value="Bachelor of Science in Criminology (BSCrim)">Bachelor of Science in Criminology (BSCrim)</option>
                                            
                                        </select></td>
                                        <td><input type="text" name="college4"></td>
                                        <td><input type="date" name="year4"></td>
                                        <td><input type="text" name="honor4"></td>
                                    </tr>
                                    <tr>
                                        <td align="center"><select name="degree5">
                                        <option value="Master of Arts in Education (MAED)">Master of Arts in Education (MAED)</option>
                                        <option value="Major: Education Administration">Major: Education Administration</option>
                                        <option value="Master in Business Administration (MBA)">Master in Business Administration (MBA)</option>
                                        <option value="Bachelor of Arts in English Language">Bachelor of Arts in English Language</option>
                                        <option value="Bachelor of Arts in Political Science">Bachelor of Arts in Political Science</option>
                                        <option value="Bachelor of Science in Mathematics">Bachelor of Science in Mathematics</option>
                                        <option value="Bachelor of Science in Biology">Bachelor of Science in Biology</option>
                                        <option value="Bachelor of Elementary Education (BSEEd)">Bachelor of Elementary Education (BSEEd)</option>
                                        <option value="Bachelor of Secondary Education (BSEd)">Bachelor of Secondary Education (BSEd)</option>
                                        <option value="Bachelor of Science in Accountancy (BSA)">Bachelor of Science in Accountancy (BSA)</option>
                                        <option value="Bachelor of Science in Accounting Information System (BSAIS)">Bachelor of Science in Accounting Information System (BSAIS)</option>
                                        <option value="Bachelor of Science in Business Administration (BSBA)">Bachelor of Science in Business Administration (BSBA)</option>
                                        <option value="Bachelor of Science in Office Administration (BSOA)">Bachelor of Science in Office Administration (BSOA)</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Tourism Management (BSTM)">Bachelor of Science in Tourism Management (BSTM)</option>
                                        <option value="Bachelor of Science in Hospitality Management">Bachelor of Science in Hospitality Management</option>
                                        <option value="Bachelor of Public Administration">Bachelor of Public Administration</option>
                                        <option value="Bachelor of Science in Information Technology (BSIT)">Bachelor of Science in Information Technology (BSIT)</option>
                                        <option value="Bachelor of Science in Criminology (BSCrim)">Bachelor of Science in Criminology (BSCrim)</option>
                                            
                                        </select></td>
                                        <td><input type="text" name="college5"></td>
                                        <td><input type="date" name="year5"></td>
                                        <td><input type="text" name="honor5"></td>
                                    </tr>
                                </table>
                                
                                <ul>
                                    <li>Degree means Program of Study or Program of Discipline, example BS in Teacher Education. </li>
                                    <li>Specialization means major field of stud, example Mathematics. </li>
                                    <li>Honors or Awards means academic awards received in college or while earning the degree. </li>
                                </ul>
                                <ol start="16">
                                    <li>Professional examination (s) Passed</li>
                                    <table border="1">
                                    <tr>
                                        <td align="center">Name of Examination</td>
                                        <td align="center">Date Taken</td>
                                        <td align="center">Rating</td>
                                    </tr>
                                    <tr>
                                        <td><input type="text" name="exam1" required></td>
                                        <td><input type="date" name="date1" required></td>
                                        <td><input type="text" name="rate1" required></td>
                                    </tr>
                                    <tr>
                                        <td><input type="text" name="exam2"></td>
                                        <td><input type="date" name="date2"></td>
                                        <td><input type="text" name="rate2"></td>
                                    </tr>
                                    <tr>
                                        <td><input type="text" name="exam3"></td>
                                        <td><input type="date" name="date3"></td>
                                        <td><input type="text" name="rate3"></td>
                                    </tr>
                                    
                                </table>
                                    <li>Reason (s) for taking the course (s) or pursuing degree (s).  You may check (/) more than one answer.</li>
                                    <a>Undergraduate/AB/BS Graduate/MS/Ma/Ph.D</a>
                                    <table border="1">
                                        <tr>
                                            <td></td>
                                            <td>Undergraduate/AB/BS</td>
                                            <td>Graduate/MS/Ph.D</td>
                                        </tr>
                                        <tr>
                                            <td>High Grades in the course or subject area (s) related to the course</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question1" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question1" value="Graduate/MS/Ph.D" style="left: 30px;"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Good grades in high school</td>
                                            
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question2" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question2" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Influence of parents or relatives</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question3" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question3" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Peer Influence</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question4" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question4" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Inspired by a role model</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question5" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question5" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Strong passion for the profession</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question6" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question6" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Prospect for immediate employment</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question7" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question7" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Status or prestige of the profession</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question8" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question8" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Availability  of course offering in chosen institution</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question9" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question9" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Prospect of career advancement</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    
                                            <input type="radio" name="question10" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question10" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Affordable for the family</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    
                                            <input type="radio" name="question11" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question11" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Prospect of attractive compensation</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question12" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question12" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Opportunity for employment abroad</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    
                                            <input type="radio" name="question13" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question13" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>No particular choice or no better idea</td>
                                            <td colspan="2">
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question14" value="Undergraduate/AB/BS" required>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="radio" name="question14" value="Graduate/MS/Ph.D"></td>
                                            
                                        </tr>
                                        <tr>
                                            <td>Others, please specify </td>
                                            <td colspan="2" align="center"><textarea name="questionSpec" style="resize:none; width:275px; height:50px;"></textarea></td>
                                            
                                        </tr>
                                    </table>
                                </ol>
                        
                    </li>
                    
            <li><b>Training (s) Advance Studies Attended After College</b>
                        <ol start="18">
                            <li> A. Please list down all professional or work-related training program (s) including advance studies you have attended after college.  You may use extra sheet if needed</li>
                            <table border="1">
                                <tr>
                                    <td align="center">Title of Training or Advance Study</td>
                                    <td align="center">Duration & Credits Earned	</td>
                                    <td align="center">Name of Training Institution/College/University</td>
                                </tr>
                                <tr>
                                    <td align="center"><input type="text" name="training1" style="width: 235px;" required></td>
                                    <td align="center"><input type="text" name="duration1" style="width: 180px;" required></td>
                                    <td align="center"><input type="text" name="nameTraining1" style="width: 310px;" required></td>
                                </tr>
                                <tr>
                                    <td align="center"><input type="text" name="training2" style="width: 235px;"></td>
                                    <td align="center"><input type="text" name="duration2" style="width: 180px;"></td>
                                    <td align="center"><input type="text" name="nameTraining2" style="width: 310px;"></td>
                                </tr><tr>
                                    <td align="center"><input type="text" name="training3" style="width: 235px;"></td>
                                    <td align="center"><input type="text" name="duration3" style="width: 180px;"></td>
                                    <td align="center"><input type="text" name="nameTraining3" style="width: 310px;"></td>
                                </tr>
                            </table>
                        </ol>
                        <ol start="18">
                            <li> B.  What made you pursue advance studies?</li>
                            <input type="radio" name="advancestudies" value="For promotion" required> For promotion <br>
                            <input type="radio" name="advancestudies" value=" For professional development"> For professional development <br>
                            <input type="radio" name="advancestudies" value="Others, please specify"> Others, please specify <input type="text">
                        </ol>
                        
                    </li>
                    
            <li><b> Employment Data</b> <br>
                        <ol start="19">(Employment here means any type of work performed or services rendered in exchanged for compensation under a contact of hire which create the employer and employee relations)
                            <li> Are you presently employed?</li>
                            <input type="radio" name="employed" value="yes" required> Yes <br>
                            <input type="radio" name="employed" value="no"> No <br>
                            <input type="radio" name="employed" value="Never Employed"> Never Employed
                            If NO or NEVER BEEN EMPLOYED,  proceed to Questions 20.
                            If YES, proceed to Questions 21 to 24.
                            <li>Please state reason (s) why you are not yet employed.  You may check (/) more than one answer.</li>
                            <input type="radio" name="res" value="Advance or further study"> Advance or further study <br>
                            <input type="radio" name="res" value="Family concern and decided not to find a job"> Family concern and decided not to find a job <br>
                            <input type="radio" name="res" value="Health-related reason (s)"> Health-related reason (s) <br>
                            <input type="radio" name="res" value="Lack of work experience"> Lack of work experience <br>
                            <input type="radio" name="res" value="No job opportunity"> No job opportunity <br>
                            <input type="radio" name="res" value="Did not look for a job"> Did not look for a job <br>
                            <input type="radio" name="res" value="Other reason (s), please specify"> Other reason (s), please specify
                            <li>Present Employment Status.</li>
                            <input type="radio" name="empstatus" value="Regular or Permanent"> Regular or Permanent <br>
                            <input type="radio" name="empstatus" value=" Temporary">  Temporary <br>
                            <input type="radio" name="empstatus" value="Casual"> Casual <br>
                            <input type="radio" name="empstatus" value="Contractuale"> Contractual <br>
                            <input type="radio" name="empstatus" value="Self- employed"> Self- employed <br>
                            <li>Present occupation <input type="text"></li>
                            ( Use the following Phil. Standard Occupational Classification (PSOC), 1992 classification) <br>
                            <input type="radio" name="occupation" value="Officials of Government and Special-Interest Organizations, Corporate Executives, Managers, Managing Proprietors and Supervisors."> Officials of Government and Special-Interest Organizations, Corporate Executives, Managers, Managing Proprietors and Supervisors. <br>
                            <input type="radio" name="occupation" value="Professionals">Professionals <br>
                            <input type="radio" name="occupation" value="Technicians and Associate Professionals"> Technicians and Associate Professionalsl <br>
                            <input type="radio" name="occupation" value="Clerks"> Clerks <br>
                            <input type="radio" name="occupation" value="Service workers and Shop and Market Sales Workers"> Service workers and Shop and Market Sales Workers <br>
                            <input type="radio" name="occupation" value="Farmers, Forestry Workers and Fishermen">Farmers, Forestry Workers and Fishermen <br>
                            <input type="radio" name="occupation" value="Trades and Related Workers">Trades and Related Workers <br>
                            <input type="radio" name="occupation" value="Plant and machine Operators and Assemblers">Plant and machine Operators and Assemblers <br>
                            <input type="radio" name="occupation" value="Laborers and Unskilled Workers">Laborers and Unskilled Workers <br>
                            <input type="radio" name="occupation" value="Special Occupation">Special Occupation <br>
                        </ol>
                        <ol start="23">
                            <li> A. Name of the Company or Organization inlcluding address <input type="text" name="companyOrg" ></li>
                            
                        </ol>
                        <ol start="23">
                            <li> B. Major line of business of the company you are  presently employed in.  Please check one only.</li>
                            (Please attached description) <br>
                            <input type="radio" name="majorline" value="Agriculture, Hunting and Forestry">Agriculture, Hunting and Forestry <br>
                            <input type="radio" name="majorline" value="Fishing"> Fishing <br>
                            <input type="radio" name="majorline" value="Mining and Quarrying">Mining and Quarrying <br>
                            <input type="radio" name="majorline" value="Manufacturing"> Manufacturing <br>
                            <input type="radio" name="majorline" value="Electricity, Gas and Water Supply">Electricity, Gas and Water Supply <br>
                            <input type="radio" name="majorline" value="Construction">Construction <br>
                            <input type="radio" name="majorline" value=" Wholesale and Retail Trade, repair of motor vehicles, motorcycles and personal and    
                               household goods"> Wholesale and Retail Trade, repair of motor vehicles, motorcycles and personal and    
                               household goods <br>
                            <input type="radio" name="majorline" value="Hotels and Restaurants">Hotels and Restaurants <br>
                            <input type="radio" name="majorline" value="Transport Storage and Communication">Transport Storage and Communication <br>
                            <input type="radio" name="majorline" value="Financial Intermediation">Financial Intermediation <br>
                            <input type="radio" name="majorline" value="Real State, Renting and Business Activities"> Real State, Renting and Business Activities <br>
                            <input type="radio" name="majorline" value="Public Administration and Defense; Compulsory Social Security.">Public Administration and Defense; Compulsory Social Security. <br>
                            <input type="radio" name="majorline" value="Education">Education <br>
                            <input type="radio" name="majorline" value="Health and Social Work">Health and Social Work <br>
                            <input type="radio" name="majorline" value="Other community, Social and Personal Service Activities">Other community, Social and Personal Service Activities <br>
                            <input type="radio" name="majorline" value="Private Households with Employed Persons">Private Households with Employed Persons <br>
                            <input type="radio" name="majorline" value="Extra-territorial Organizations and Bodies">Extra-territorial Organizations and Bodies <br>
                        </ol>
                        <ol start="24">
                            <li>Place of Work</li>
                            <input type="radio" name="placeWork" value="Local">Local <br>
                            <input type="radio" name="placeWork" value="Abroad">Abroad <br>
                            <li>Is this your first job after college? If NO proceed to Question 27 and 28</li>
                            <input type="radio" name="fjob" value="Yes" required>Yes <br>
                            <input type="radio" name="fjob" value="No">No <br>
                            <li>What are the reason (s) for staying on the job? You may check (/) more than one answer.</li>
                            <input type="radio" name="sjob" value="Salaries and benefits">Salaries and benefits <br>
                            <input type="radio" name="sjob" value="Related to special skill">Related to special skill <br>
                            <input type="radio" name="sjob" value="Related to course or program of study">Related to course or program of study <br>
                            <input type="radio" name="sjob" value="Proximity to residence"> Proximity to residence <br>
                            <input type="radio" name="sjob" value="Peer influence">Peer influence<br>
                            <input type="radio" name="sjob" value="Family influence">Family influence<br>
                            <input type="radio" name="sjob" value="Other reason (s), please specify ">Other reason (s), please specify  <input type="text"><br>
                            Please proceed to Question 24.
                            <li>Is your first job related to the course you took up in college?</li>
                            <input type="radio" name="relatedJob" value="Yes">Yes <br>
                            <input type="radio" name="relatedJob" value="No">No <br>
                            <li>What were your reasons for accepting the job?  You may check (/) more than one answer.</li>
                            
                            <input type="checkbox" name="acceptJob" value="Salaries and benefits">Salaries and benefits<br>
                            <input type="checkbox" name="acceptJob" value="Career challenge">Career challenge<br>
                            <input type="checkbox" name="acceptJob" value="Related to special skills">Related to special skills<br>
                            <input type="checkbox" name="acceptJob" value="Proximity to residence">Proximity to residence<br>
                            <input type="checkbox" name="acceptJob" value="Car">Other reason (s), please specify <input type="text"><br>
                            
                            <li>What were your reason (s) for changing job? You may check (/) more than one answer.</li>
                            
                            <input type="checkbox" name="changeJob" value="Salaries and benefits" required>Salaries and benefits<br>
                            <input type="checkbox" name="changeJob" value="Career challenge">Career challenge<br>
                            <input type="checkbox" name="changeJob" value="Related to special skills">Related to special skills<br>
                            <input type="checkbox" name="changeJob" value="Proximity to residence">Proximity to residence<br>
                            <input type="checkbox" name="changeJob" value="Car">Other reason (s), please specify <input type="text"><br>
                            
                            <li>How long did you stay in your first job?</li>
                            <input type="radio" name="longStay" value="Less than a month" required>Less than a month<br>
                            <input type="radio" name="longStay" value="1 to 6 months">1 to 6 months  <br>
                            <input type="radio" name="longStay" value="7 to 11 months">7 to 11 months <br>
                            <input type="radio" name="longStay" value="1 year to less than 2 years">  1 year to less than 2 years<br>
                            <input type="radio" name="longStay" value="2 years to less than 3 years">2 years to less than 3 years<br>
                            <input type="radio" name="longStay" value="3 years to less than 4 years">3 years to less than 4 years<br>
                            <input type="radio" name="longStay" value="Self- employed"> Others, please specify <input type="text"><br>
                            <li>How did you find your first job?</li>
                            <input type="radio" name="findfjob" value="Response to an advertisement" required>Response to an advertisement<br>
                            <input type="radio" name="findfjob" value=" As walk-in applicant"> As walk-in applicant<br>
                            <input type="radio" name="findfjob" value="Recommended by someone">Recommended by someone <br>
                            <input type="radio" name="findfjob" value="Information from friends">Information from friends<br>
                            <input type="radio" name="findfjob" value="Arranged by school’s job placement officer">Arranged by school’s job placement officer<br>
                            <input type="radio" name="findfjob" value="Family business">Family business<br>
                            <input type="radio" name="findfjob" value="Job Fair or Public Employment Service Office (PESO)">Job Fair or Public Employment Service Office (PESO)<br>
                            <input type="radio" name="findfjob" value="Others, please specify">Others, please specify <input type="text"><br>
                            <li>How long did it take you to land your first job?</li>
                            <input type="radio" name="landfjob" value=" Less than a month" required> Less than a month<br>
                            <input type="radio" name="landfjob" value="1 to 6 months ">1 to 6 months <br>
                            <input type="radio" name="landfjob" value="7 to 11 months ">7 to 11 months  <br>
                            <input type="radio" name="landfjob" value="1 year to less than 2 years">1 year to less than 2 years<br>
                            <input type="radio" name="landfjob" value=" 2 years to less than 3 years"> 2 years to less than 3 years<br>
                            <input type="radio" name="landfjob" value="3 years to less than 4 years">3 years to less than 4 years<br>
                            <input type="radio" name="landfjob" value="Others, please specify">Others, please specify <input type="text"><br>
                            <li>Job Level Position.</li>
                            <table border="1">
                                <tr>
                                    <td align="center">Job Level</td>
                                    <td>30.1. First Job</td>
                                    <td>30.2. Current or Present Job</td>
                                </tr>
                                <tr>
                                    <td>Rank or Clerical</td>
                                    <td colspan="2">
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="rcle" value="First Job" required>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="rcle" value="Current or Present Job"></td>
                                    
                                </tr>
                                <tr>
                                    <td>Professional, Technical or Supervisory</td>
                                    <td colspan="2"> 
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="pts" value="First Job" required>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="pts" value="Current or Present Job"></td>
                                    
                                </tr>
                                <tr>
                                    <td>Managerial or Executive</td>
                                    <td colspan="2">
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="me" value="First Job" required>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="me" value="Current or Present Job"></td>
                                    
                                </tr>
                                <tr>
                                    <td>Self-employed</td>
                                    <td colspan="2"> 
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    
                                    <input type="radio" name="selfemp" value="First Job" required>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="selfemp" value="Current or Present Job"></td>
                                    
                                </tr>
                            </table>
                            <li>What is your  initial gross monthly earning  in your  first job after college?</li>
                            <input type="radio" name="gross" value=" Below P 5,000.00" required>Below P 5,000.00<br>
                            <input type="radio" name="gross" value="P 5,000.00 to less than P 10,000.00 ">P 5,000.00 to less than P 10,000.00 <br>
                            <input type="radio" name="gross" value="P 10,000.00 to less than P 15,000.00">P 10,000.00 to less than P 15,000.00 <br>
                            <input type="radio" name="gross" value="P 15,000.00 to less than P 20,000.00">P 15,000.00 to less than P 20,000.00<br>
                            <input type="radio" name="gross" value="P 20,000.00 to less than P 25,000.00">P 20,000.00 to less than P 25,000.00<br>
                            <input type="radio" name="gross" value="P 25,000.00  and above">P 25,000.00  and above<br>
                            <li>Was the curriculum you had in college relevant to your first job?</li>
                            <input type="radio" name="relevantfjob" value="Yes" required>Yes<br>
                            <input type="radio" name="relevantfjob" value="No">No <br>
                            <li>If YES, what competencies learned in college did you find very useful in your first job?  You may check (/) more than one answer.</li>
                            <input type="radio" name="usefjob" value="Communication skills" required>Communication skills<br>
                            <input type="radio" name="usefjob" value="Human Relations skills">Human Relations skills <br>
                            <input type="radio" name="usefjob" value="Entrepreneurial skills">Entrepreneurial skills<br>
                            <input type="radio" name="usefjob" value="Problem-solving skills">Problem-solving skills<br>
                            <input type="radio" name="usefjob" value="Critical Thinking skills">Critical Thinking skills<br>
                            <input type="radio" name="usefjob" value="Others, please specify">Others, please specify <input type="text"><br>
                            <li>is your current job related to the course you took up in college?</li>
                            <input type="radio" name="currentjob" value="Yes" required>Yes<br>
                            <input type="radio" name="currentjob" value="No">No <br>
                            <li>List down suggestions to further improve your course curriculum</li>
                            <textarea name="suggest" form="usrform"></textarea>
                        </ol>
                    </li>
                    
                    
                </ol>
        
                <input type="submit" name="submitall" style="width: 150px; height: 40px; font-size: 20px;"> <br>
                <a href="index.php" style="color:black;">BACK TO HOME</a> <br>
                <a href="user.php" style="color:black;">BACK TO MY ACCOUNT</a>
		</form>
	</body>

<html>