<?php
    ini_set('mysql.connect_timeout', 300);
    ini_set('default_socket_timeout', 300);
    include "connection.php";
    session_start();

    $result = mysqli_query($conn, "SELECT * FROM alumni_account");
    $num_rows = mysqli_num_rows($result);
    
    $result2 = mysqli_query($conn, "SELECT * FROM `alumni_account` WHERE STATUS = 'active'");
    $num_rows_active = mysqli_num_rows($result2);


    if(isset($_POST['submitPost'])){
        $postUpdate = $_POST['postupdate'];
        $getDate = date("Y/m/d");
        
        if(getimagesize($_FILES['image']['tmp_name'])== FALSE)
             {
                echo "Please select an image. ";
             }
                else
             {
                     $image = addslashes($_FILES['image']['tmp_name']);
                     $name = addslashes($_FILES['image']['name']);
                     $image = file_get_contents($image);
                     $image = base64_encode($image);
                     //saveimage($name, $image);
             }
        
        $query2 = "INSERT INTO image_post_update (date, post, name, image) VALUES ('$getDate', '$postUpdate', '$name', '$image')";
        
        if(mysqli_query($conn, $query2)){
            echo "<script type='text/javascript'>alert('Posted successfully!')</script>";
            ////header("location: adminannc.php");
            
        }
        else{
            echo mysqli_error();
        }
    }
    
//////////////////////////////////////////////////////
    
    if(isset($_POST['submitEdit'])){
        $textEdit = $_POST['textEdit'];
        $postEdit = $_POST['postEdit'];
        
        $query3 = "UPDATE image_post_update SET post = '$postEdit' WHERE id = $textEdit";
        
        if(mysqli_query($conn, $query3)){
            echo "<script type='text/javascript'>alert('Post Edited successfully!')</script>";
            
        }
        else{
            echo mysqli_error();
        }
    }

    function saveimage($name, $image) 
        {
            include "connection.php";
            $query = "INSERT INTO image_post_update (name, image) VALUES ('$name','$image')";
            $result = mysqli_query($conn, $query);
            if($result)
            {
                echo "<br/> Image uploaded";
            }
            else{
                echo "<br/> Image not uploaded";
            }
        }
?>


<html>
	<head>
		<title>Admin</title>
        
        <style>
            #nav1 h1{
                float: left;
                font-size: 2.5em;
                margin-left: 15px;
                padding-left: 30px;
            }
            #nav1 h1 a{
                text-decoration: none;
                color: white;
            }
            #nav1 ul{
                float: right;
                margin-right: 15px;
            }
            #nav1 ul li{
                display: inline-block;
                list-style-type: none;

            }
            #nav1 ul li a{
                text-decoration: none;
                color: black;
                padding: 25px;
            }
            #nav1 ul li:hover{
                background: #a09e9e;
                transition: all ease-in-out 0.45s;
            }
            table {
                border-collapse: collapse;
                width: 70%;
                color: black;
                font-family: sans-serif;
                font-size: 14px;
                text-align: left;
            }
            th{
                background-color: #800000;
                color: white;
                width: 10%
            }
            body{
                background-color: #800000;
            }
            hr{
                color: #800000;
            }
        </style>
        
		
        <link href="css/admin.css" rel="stylesheet" type="text/css">
	</head>
	
	<body background="back.png" style="background-color: #800000">
		<div class="loginbox" style="height: 600px; width: 1100px; overflow:auto;  ">
		
		<?php if(isset($_SESSION['usernameAdmin'])): ?>
            
		<form action="adminannc.php" method="post" enctype="multipart/form-data">
            
            <div id="nav1">
                
                <ul>
                    <?php 
                        $queryNumAlum = "SELECT COUNT(*) AS count FROM alumni_account WHERE status = 'inactive'";
                        $resultNumAlum = $conn-> query($queryNumAlum);

                        while ($row = $resultNumAlum->fetch_assoc()) {

                        $resNumAlum = $row['count'];
                            echo '<li id="active"><a href="adminacc.php" style="font-size:15px;"> Admin Account</a></li>';
                            if($resNumAlum > 0) {
                                echo '<li><a href="admininfo.php" style="color:red; font-size:15px;"> Information Notification/Report ('.$resNumAlum.')</a></li>';
                            }
                            else {
                                echo '<li><a href="admininfo.php" style="font-size:15px;"> Information Notification/Report ('.$resNumAlum.')</a></li>';
                            }
                            echo '<li><a href="adminannc.php" style="font-size:15px;"> Announcement and School Update</a></li>';
                            echo '<li><a href="admingrad.php" style="font-size:15px;"> Graduate List</a></li>';
                            echo '<li><a href="logout.php" style="font-size:15px;"> Logout</a></li>';
                        }
                    ?>
                </ul>
		    </div>
            
            <br><br><br><br><br>
            
            <div class="panel3">
                <b>Announcement and School Updates</b>
                <h2 style="font-size:13px;">Total # of Registered Alumni: <?php echo $num_rows ?></h2>
                <h2 style="font-size:13px;">List of Registered Alumni: <?php echo $num_rows_active ?></h2>
                <table border="1" frame="hsides" rules="rows" style="font-size:14px;">
                    <th>ID</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Alumni ID</th>
                    <th>Status</th>
                    
                    <?php
                    
                        $sql = "SELECT id, username, password, alumni_id, status FROM alumni_account WHERE status = 'active'";
                        $result = $conn-> query($sql);

                        if($result-> num_rows > 0) {
                            while ($row = $result -> fetch_assoc()){
                                echo "<tr><td>". $row["id"] ."</td>
                                <td>" .$row["username"]. "</td>
                                <td>" .$row["password"]. "</td>
                                <td>" .$row["alumni_id"]. "</td>
                                <td>" .$row["status"]. "</td></tr>"; 
                            }
                            echo "</table>";
                        }
                        else{
                            echo "0 result";
                        }
                    ?>
                </table>
                <h2 style="font-size:13px;">Post Announcement and School Event Updates: </h2>
                <textarea rows="4" cols="50" name="postupdate" style=" resize: none; width: 840px; height:100px;"></textarea>
                <h2 style="font-size:13px;">Upload Photo: <input type="file" name="image" accept="image/*" style="width:190px;"></h2>
            </div>
            
            <br>
            <input type="submit" name="submitPost">
            
            <br><br>
            <b>Edit School Announcement's Post</b>
            <br><br>
            <table>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Post</th>
                    
                <?php
                    
                    $sql = "SELECT id, date AS date_post, post FROM image_post_update";
                        $result = $conn-> query($sql);

                        if($result-> num_rows > 0) {
                            while ($row = $result -> fetch_assoc()){
                                echo "<tr><td>". $row["id"] ."</td>
                                <td>" .$row["date_post"]. "</td>
                                <td>" .$row["post"]. "</td></tr>"; 
                            }
                            echo "</table>";
                        }
                        else{
                            echo "0 result";
                        }
                
                ?>
            </table>
            <h2 style="font-size:14px;">Enter post ID to edit: <input type="text" name="textEdit" style="height:14px; font-size:14px;"></h2>
            <textarea rows="4" cols="50" name="postEdit" style=" resize: none; width: 840px; height:100px;"></textarea>
            <br><br>
            <input type="submit" name="submitEdit" value="Edit Post">
            <br><br>
            
            
            <a href="index.php" style="bottom-right: 1000px;">Back to Home</a>
            
            <?php else: ?>
            <h3 style="color:black; text-align:center; font-size: 30px;">Please Login first</h3>
            <a href="index.php" style="bottom-right: 1000px; text-align:center; padding-left:500px;">Back to Home</a>
            <?php endif; ?>
        </form>
		</div>
        
        
            
	</body>
</html>