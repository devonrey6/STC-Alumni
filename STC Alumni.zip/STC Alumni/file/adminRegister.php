<?php
    include "connection.php";
    
    if(isset($_POST['submit'])){
        
        $username = $_POST['username'];
        $password = $_POST['password'];
        $alumniID = $_POST['alumni_id'];
        $status = 'inactive';
        
        $query = "INSERT INTO admin_account (username, password, name, status) VALUES ('$username', '$password', '$alumniID', 'inactive')";
        
        $check = mysqli_query($conn, "SELECT * FROM admin_account WHERE username='$username'");
        $checkrows = mysqli_num_rows($check);
        
        
        if($checkrows>0){
            echo "<script type='text/javascript'>alert('Username Already ')</script>";
        }else{
            mysqli_query ($conn, $query);
            echo "<script type='text/javascript'>alert('Registered Succesfully')</script>";
        }
    }

?>


<html>
	<head>
		<title>Admin Registration</title>
		<link href="css/register.css" rel="stylesheet" type="text/css">
	</head>
	
	<body >
		<div class="loginbox" style="height: 460px;">
		<img src="images/avatar.png" class="avatar">
		<h1>Admin Registration</h1>
		<form action="adminRegister.php" method="post">
			<p>Username</p>
			<input type="text" name="username" placeholder="Enter Username" required>
			<p>Password</p>
			<input type="password" name="password" placeholder="Enter Password" minlength="6" required>
			<p>Name </p>
			<input type="text" name="alumni_id" placeholder="Enter Full Name" required>
			
			<input type="submit" name="submit" value="Confirm Registration">
			<a href="index.php">Back to Home</a>
			
		<form>
		</div>
	</body>
</html>