<?php
    include "connection.php";
    
    if(isset($_POST['submit'])){
        
        $username = $_POST['username'];
        $password = $_POST['password'];
        $alumniID = $_POST['alumni_id'];
        $status = 'inactive';
        $id = 0;
        $query = "INSERT INTO alumni_account (username, password, alumni_id, status) VALUES ('$username', '$password', '$alumniID', 'inactive')";
        
        $check = mysqli_query($conn, "SELECT * FROM alumni_account WHERE username='$username'");
        $checkrows = mysqli_num_rows($check);
        
        
        if($checkrows>0){
            echo "<script type='text/javascript'>alert('Username Already Exist')</script>";
        }else{
            
            mysqli_query ($conn, $query);
            echo "<script type='text/javascript'>alert('Please wait for some minutes to the admin for the confirmation of your account; Security check. Thank you')</script>";
        }
    }

?>


<html>
	<head>
		<title>Register</title>
		<link href="css/register.css" rel="stylesheet" type="text/css">
	</head>
	
	<body >
		<div class="loginbox" style="height: 460px;">
		<img src="images/avatar.png" class="avatar">
		<h1> Registration</h1>
		<form action="register.php" method="post">
			<p>Username</p>
			<input type="text" name="username" placeholder="Enter Username" required>
			<p>Password</p>
			<input type="password" name="password" placeholder="Enter Password" minlength="6" required>
			<p>Alumni ID</p>
			<input type="text" name="alumni_id" placeholder="Enter Alumni ID" onkeypress="isInputNumber(event)" required>
			
            <script>
                
                function isInputNumber(evt) {
                    var ch = String.fromCharCode(evt.which);
                    
                    if(!(/[0-9]/.test(ch))) {
                        evt.preventDefault();
                    }
                    
                }
                
            </script>
            
			<input type="submit" name="submit" value="Confirm Registration">
            <a href="adminRegister.php">Admin Account Registration</a><br>
			<a href="index.php">Back to Home</a>
			
		<form>
		</div>
	</body>
</html>