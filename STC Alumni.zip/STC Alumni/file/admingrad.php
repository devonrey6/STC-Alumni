<?php
    include "connection.php";
    session_start();
    
    if(isset($_POST['addAlum'])){
        $fname = $_POST['fname'];
        $gender = $_POST['gender'];
        $date = $_POST['date'];
        $bplace = $_POST['bplace'];
        $paddress = $_POST['paddress'];
        $degree = $_POST['degree'];
        $contact = $_POST['contact'];
        $email = $_POST['email'];
        $dept = $_POST['dept'];
        $year = $_POST['year'];
        
        $query4 = "INSERT INTO graduate_list (name, gender, bdate, bplace, present_add, degree, contact, email, department, year_grad) VALUES ('$fname', '$gender', '$date', '$bplace', '$paddress', '$degree', '$contact', '$email', '$dept', '$year')";
        
        if(mysqli_query($conn, $query4)){
            //header("location: admingrad.php");
            echo "<script type='text/javascript'>alert('Alumni Added successfully!')</script>";
        }else{
            echo mysqli_error();
        }
    }

    if(isset($_POST['search'])){
        
        $query5 = "SELECT name, gender, bdate, bplace, present_add, degree, contact, email, department, year_grad FROM graduate_list WHERE department = 'College of Arts & Sciences'";
    }
    



    if(isset($_POST['search'])){

        $valueToSearch = $_POST['valueToSearch'];
        $searchType = $_POST['searchType'];
        
        $query = "SELECT id, name, gender, bdate, bplace, present_add, degree, contact, email, department, year_grad FROM graduate_list WHERE $searchType = '$valueToSearch'";
        $search_result = filterTable($query);
        
    }else if(isset($_POST['clearSearch'])){
        $query = "SELECT * FROM `graduate_list`";
        $search_result = filterTable($query);
    }else{
        $query = "SELECT * FROM `graduate_list`";
        $search_result = filterTable($query);
    }
    

    function filterTable($query){
        include "connection.php";
        $filter_Result = mysqli_query($conn, $query);
        return $filter_Result;
    }

?>


<html>
	<head>
		<title>Admin</title>
        
        <style>
            #nav1 h1{
                float: left;
                font-size: 2.5em;
                margin-left: 15px;
                padding-left: 30px;
            }
            #nav1 h1 a{
                text-decoration: none;
                color: white;
            }
            #nav1 ul{
                float: right;
                margin-right: 15px;
            }
            #nav1 ul li{
                display: inline-block;
                list-style-type: none;

            }
            #nav1 ul li a{
                text-decoration: none;
                color: black;
                padding: 25px;
            }
            #nav1 ul li:hover{
                background: #a09e9e;
                transition: all ease-in-out 0.45s;
            }
            table {
                border-collapse: collapse;
                width: 70%;
                color: black;
                font-family: sans-serif;
                font-size: 14px;
                text-align: left;
            }
            th{
                background-color: #800000;
                color: white;
                width: 10%
            }
            body{
                background-color: #800000;
            }
            hr{
                color: #800000;
            }
            
        </style>
        
		
        <link href="css/admin.css" rel="stylesheet" type="text/css">
	</head>
	
	<body background="back.png" style="background-color: #800000">
		<div class="loginbox" style="height: 600px; width: 1100px; overflow:auto;  ">
		
		<?php if(isset($_SESSION['usernameAdmin'])): ?>
            
		<form action="admingrad.php" method="post">
            
            <div id="nav1">
                
                <ul>
                    <?php 
                        $queryNumAlum = "SELECT COUNT(*) AS count FROM alumni_account WHERE status = 'inactive'";
                        $resultNumAlum = $conn-> query($queryNumAlum);

                        while ($row = $resultNumAlum->fetch_assoc()) {

                        $resNumAlum = $row['count'];
                            echo '<li id="active"><a href="adminacc.php" style="font-size:15px;"> Admin Account</a></li>';
                            if($resNumAlum > 0) {
                                echo '<li><a href="admininfo.php" style="color:red; font-size:15px;"> Information Notification/Report ('.$resNumAlum.')</a></li>';
                            }
                            else {
                                echo '<li><a href="admininfo.php" style="font-size:15px;"> Information Notification/Report ('.$resNumAlum.')</a></li>';
                            }
                            echo '<li><a href="adminannc.php" style="font-size:15px;"> Announcement and School Update</a></li>';
                            echo '<li><a href="admingrad.php" style="font-size:15px;"> Graduate List</a></li>';
                            echo '<li><a href="logout.php" style="font-size:15px;"> Logout</a></li>';
                        }
                    ?>
                </ul>
		    </div>
            
            <br><br><br><br><br>
            
            <b>Graduate List (Add & Edit)</b>
            
            <br><br>
            <table style="width: 0px:">
                <tr>
                    <td><h2 style="font-size:14px; height:14px;">Name: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="fname" style="font-size:14px; height:14px; width: 100px;"></h2></td>
                    <td><h2 style="font-size:14px; height:14px;">Gender: <input type="radio" name="gender" value="male" checked> Male
                        <input type="radio" name="gender" value="female"> Female</h2></td>
                </tr>
                <tr>
                    <td><h2 style="font-size:14px; height:14px;">Birth Day: &nbsp;&nbsp;<input type="date" name="date" style="width:130px;" style="font-size:14px; height:14px; width: 100px;"></h2></td>
                    <td><h2 style="font-size:14px; height:14px;">Birth Place: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="bplace" style="font-size:14px; height:14px; width: 100px;"></h2></td>
                </tr>
                <tr>
                    <td><h2 style="font-size:14px; height:14px;">Present Address: <input type="text" name="paddress" style="font-size:14px; height:14px; width: 300px;"></h2></td>
                    <td><h2 style="font-size:14px; height:14px;">Degree: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="degree" style="font-size:14px; height:14px; width: 100px;"></h2></td>
                </tr>
                <tr>
                    <td><h2 style="font-size:14px; height:14px;">Contact: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="contact" style="font-size:14px; height:14px; width: 100px;" onkeypress="isInputNumber(event)"></h2></td>
                    
                    <script>
                
                        function isInputNumber(evt) {
                            var ch = String.fromCharCode(evt.which);

                            if(!(/[0-9]/.test(ch))) {
                                evt.preventDefault();
                            }

                        }

                    </script>
                    
                    <td><h2 style="font-size:14px; height:14px;">Email: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="email" style="font-size:14px; height:14px; width: 100px;"></h2></td>
                </tr>
                <tr>
                    <td><h2 style="font-size:14px; height:14px;">Department: &nbsp;<select name="dept" style="font-size:14px;">
                                        <option value="College of Arts & Sciences">College of Arts & Sciences</option>
                                        <option value="College of Teacher Education">College of Teacher Education</option>
                                        <option value="College of Accountancy">College of Accountancy</option>
                                        <option value="College of Business and Management Education">College of Business and Management Education</option>
                                        <option value="College of Information Technology">College of Information Technology</option>
                                        <option value="College of Criminology">College of Criminology</option>
                            </select></h2></td>
                    <td><h2 style="font-size:14px; height:14px;">Year Graduate: &nbsp;&nbsp;<input type="text" name="year" style="font-size:14px; height:14px; width: 100px;"></h2></td>
                </tr>
            </table>
            
            <h2><input type="submit" value="Add Alumni" name="addAlum"> </h2> <br>
            <h2 style="font-size:14px; height:14px;">Search: 
            <select name="searchType">
                        <option value="department">Department</option>
                        <option value="degree">Major</option>
                        <option value="year_grad">Year Graduated</option>
            </select>
            <input type="text" name="valueToSearch" style="font-size:14px; height:14px; width: 130px;">
            <input type="submit" style="height:22px; width:90px;" name="search" value="Search">
            <input type="submit" value="Clear Search" name="clearSearch" style="height:22px; width:90px;"></h2> <br>
            
                    
            <table style="width:100%;" border="1" frame="hsides" rules="rows" style="font-size:14px;">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Birthdate</th>
                    <th>Birthplace</th>
                    <th>Present Address</th>
                    <th>Degree</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Year Graduated</th>
                </tr>
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['gender'];?></td>
                    <td><?php echo $row['bdate'];?></td>
                    <td><?php echo $row['bplace'];?></td>
                    <td><?php echo $row['present_add'];?></td>
                    <td><?php echo $row['degree'];?></td>
                    <td><?php echo $row['contact'];?></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['department'];?></td>
                    <td><?php echo $row['year_grad'];?></td>
                    
                </tr>
                <?php endwhile;?>
            </table>
            <br>
            <input type="submit" value="Retrieve">
            
            
                
            <a href="index.php" style="bottom-right: 1000px;">Back to Home</a>
            
            <?php else: ?>
            <h3 style="color:black; text-align:center; font-size: 30px;">Please Login first</h3>
            <a href="index.php" style="bottom-right: 1000px; text-align:center; padding-left:500px;">Back to Home</a>
            <?php endif; ?>
            
        </form>
		</div>
        
        
            
	</body>
</html>