<html>
    <head>
        <script>
            $('.ml3').each(function(){
              $(this).html($(this).text().replace(/([^\x00-\x80]|\w)/g, "<span class='letter'>$&</span>"));
            });

            anime.timeline({loop: true})
              .add({
                targets: '.ml3 .letter',
                opacity: [0,1],
                easing: "easeInOutQuad",
                duration: 2250,
                delay: function(el, i) {
                  return 150 * (i+1)
                }
              }).add({
                targets: '.ml3',
                opacity: 0,
                duration: 1000,
                easing: "easeOutExpo",
                delay: 1000
              });
        </script>
        <style>
            .ml3 {
              font-weight: 900;
              font-size: 3.5em;
            }
        </style>
    </head>
    <body>
    
    <h1 class="ml3">Great Thinkers</h1>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    
    </body>
</html>