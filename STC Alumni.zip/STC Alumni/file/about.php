<html>
	<head>
		<title>About</title>
		<link href="css/about.css" rel="stylesheet" type="text/css">
	</head>
	
	<body >
		<div class="loginbox">
		<img src="images/about.png" class="avatar">
		<h1> About</h1>
		<form class="data">
			
            <h3>Address</h3>
            <p>Tandag City, Surigao Del Sur</p>
            <h3>Contact Number</h3>
            <p>(+6386) 211 3046 (telefax)</p>
            <h3>Website</h3>
            <p>http://www.stctandag.edu.ph/</p>
            <h3>Email Address</h3>
            <p>(+6386) 211 3046 (telefax)</p>
            
			
		<form>
            <br><br>
            <a href="index.php">Back to Home</a>
		</div>
	</body>
</html>