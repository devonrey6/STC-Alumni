<?php
    session_start();

?>

<html>
	<head>
		<title>Saint Theresa College Tracer Website</title>
		<link href="css/style.css" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        
        
        <style>
            #main-content a:hover{
                color: #ffc107;
            }
            .yas:hover{
                color: #ffc107;
            }
            #navuser ul{
                float: right;
                margin-right: 15px;
            }
            #navuser ul li{
                display: inline-block;
                list-style-type: none;
            }
            #navuser ul li a{
                text-decoration: none;
                color: black;
            }
            #navuser li{
                font-size: 10px;
            }
            #navuser a{
                text-decoration: none;
            }
            #navuser a:hover{
                color: #ffc107;
            }
            #footer{
                width:100%;
                height: 100px;
                background: rgba(47, 49, 49, 0.91);
                line-height: 100px;
            }
            

        </style>
	</head>

	<body>
        <?php if(isset($_SESSION['username'])): ?>
        
        <div id="navuser">
			<ul>
				<li><a href="user.php">Welcome: <?php echo $_SESSION['username']; ?> </a></li>
				<li>|</li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
        <?php else: ?>
		<div id="navhead">
			<ul>
				<li><a href="login.php">Login</a></li>
				<li>|</li>
				<li><a href="register.php">Register</a></li>
			</ul>
		</div>
		<?php endif; ?>
        
		<div id="nav1">
			<h1> <a href="index.html"> <img src="images/stc_sds.png"> </a> </h1>
			<ul>
				<li id="active"><a href="index.php" id="underline"> Home</a></li>
				<li><a href="about.php"> About</a></li>
				
				<li><a href="updates.php"> Updates</a></li>
				<li><a href="reports.php"> Demographic</a></li>
			</ul>
		</div>
		
        
        
        
        
		<div class="main-banner" id="main-banner">

      <div class="imgban" id="imgban1">
        <img src="">
        <br><br><br>
              <h1 style="font-family: verdana; font-size: 50px;"> Welcome Alumna & Alumnus</h1>

              <br><br><br>
              <h1>Saint Theresa College Alumni Tracer System</h1>
              <a id="yas" href="register.php" style="text-decoration: none; font-size:10px; color:#ffc107;">Please make an account to know the latest updates</a>
      </div>
      <div class="imgban" id="imgban2">
        <div class="imgban-box">
            <h2>Saint Theresa College</h2>
            <p style="font-size:20px;">Tandag City</p>
        </div>
      </div>
    </div>

    <script>
      var bannerStatus = 1;
        var bannerTimer = 3000;

        window.onload = function() {
            bannerLoop();
        }

        var startBannerLoop = setInterval(function() {
           bannerLoop();
        }, bannerTimer);

        document.getElementById("main-banner").onmouseenter = function() {
            clearInterval(startBannerLoop);
        }

        document.getElementById("main-banner").onmouseleave = function() {
           startBannerLoop = setInterval(function() {
           bannerLoop();
           }, bannerTimer);
        }



        function bannerLoop() {
            if (bannerStatus === 1) {
                document.getElementById("imgban2").style.opacity = "0";
                setTimeout(function() {
                    document.getElementById("imgban1").style.right = "0px";
                    document.getElementById("imgban1").style.zIndex = "1000";
                    document.getElementById("imgban2").style.right = "-100%";
                    document.getElementById("imgban2").style.zIndex = "1500";
                }, 500);
                setTimeout(function() {
                    document.getElementById("imgban2").style.opacity = "1";
                }, 1000);


                bannerStatus = 2;
            }
            else if (bannerStatus === 2) {
                document.getElementById("imgban1").style.opacity = "0";
                setTimeout(function() {
                    document.getElementById("imgban2").style.right = "0px";
                    document.getElementById("imgban2").style.zIndex = "1000";
                    document.getElementById("imgban1").style.right = "100%";
                    document.getElementById("imgban1").style.zIndex = "1500";
                }, 500);
                setTimeout(function() {
                    document.getElementById("imgban1").style.opacity = "1";
                }, 1000);


                bannerStatus = 1;
            }


        }
    </script>
		
        
        
        
        
        
        
		<div id="third">
			
			
			<div id="third1"> 
				<h3>Colleges & Courses<h3> <br>
				<ul>
                    
                    <div id="div1">
                        <li style="font-size: 14px;">Graduate School</li>
                    <ul style="list-style-type: none; font-weight: 100; padding-left: 18px;">
                        <li>Master of Arts in Education (MAED)</li>
                        <li>Major: Education Administration</li>
                        <li>Master in Business Administration (MBA)</li>
                        
                    </ul>
                    </div>
                    
                    
                    <div id="div2">
                        <li style="font-size: 14px;">College of Arts & Sciences (CAS)</li>
                    <ul style="list-style-type: none; font-weight: 100; padding-left: 18px;">
                        <li>Bachelor of Arts in English Language</li>
                        <li>Bachelor of Arts in Political Science</li>
                        <li>Bachelor of Science in Mathematics</li>
                        <li>Bachelor of Science in Biology</li>
                    </ul>
                    </div>
					
                    <div id="div3">
                        <li style="font-size: 14px;">College of Teacher Education (CTE)</li>
                    <ul style="list-style-type: none; font-weight: 100; padding-left: 18px;">
                        <li>Bachelor of Elementary Education (BSEEd)</li>
                        <li>Bachelor of Secondary Education (BSEd)</li>
                    </ul>
                    </div>
					
                    <div id="div4">
                        <li style="font-size: 14px;">College of Accountancy (COA)</li>
                    <ul style="list-style-type: none; font-weight: 100; padding-left: 18px;">
                        <li>Bachelor of Science in Accountancy (BSA)</li>
                        <li>Bachelor of Science in Accounting Information System (BSAIS)</li>
                    </ul>
                    </div>
					
                    <div id="div5">
                        <li style="font-size: 14px;">College of Business and Management Education (CBME)</li>
                    <ul style="list-style-type: none; font-weight: 100; padding-left: 18px;">
                        <li>Bachelor of Science in Business Administration (BSBA)</li>
                        <li>Majors: Financial Management, Marketing Management & Operation Management</li>
                        <li>Bachelor of Science in Office Administration (BSOA)</li>
                        <li>Bachelor of Public Administration</li>
                        <li>Majors: Local Government Administration; Organization and Management; Public Fiscal Administration</li>
                        <li>Bachelor of Science in Tourism Management (BSTM)</li>
                        <li>Bachelor of Science in Hospitality Management</li>
                    </ul>
                    </div>
					
                    <div id="div6">
                        <li style="font-size: 14px;">College of Information Technology</li>
                    <ul style="list-style-type: none; font-weight: 100; padding-left: 18px;">
                        <li>Bachelor of Science in Information Technology (BSIT)</li>
                    </ul>
                    </div>
                    
                    <div id="div7">
                        <li style="font-size: 14px;">College of Criminology (COC)</li>
                    <ul style="list-style-type: none; font-weight: 100; padding-left: 18px;">
                        <li>Bachelor of Science in Criminology (BSCrim)</li>
                    </ul>
                    </div>
                    
                    
				</ul>
			</div>
			
			<div id="third1"> 
					<h2>Vision</h2> <br>
                    <div id="vis1">
                        <a>Saint Theresa College envisions a fully transformed Christian Academic Community responsive to global realities.</a>
                    </div>
					
					<br>
					<h2>Mission</h2> <br>
                    <div id="mis1">
                        <a>Guided by the vision and inspired by the virtues of St. Therese of the Child Jesus, Saint Theresa College is committed to;</a> <br><br>
					</div>
                    <div id="mis2">
                    <ol>
						<li>Form evangelized and committed evangelizers who will strive their bes to serve and promote the interest of their fellowmen.</li>
						<li>Provide academic, spiritual and co-curricular activities that enhance development of the Christian person towards building a transformed society.</li>
						<li>Produce highly competent graduates with a sense of responsible leadership in the local and international communities.</li>
						<li>Help uplift the condition of the poor and the oppressed thus, transforming them into worshipping, witnessing and self-sutaining community.</li>
					</ol>
                    </div>
                    
                    
					
					
			</div>
			
			<div id="third1"> 
					<h2>Goals</h2> <br>
                    <div id="goal1">
                        <a>To achieve the school's vision and mission, the following are its goals:</a><br><br>
                    </div>
                    <div id="goal2">
                        <ol>
						<li>To provide students authentic, quality Christian education equipped with the knowledge, skills and values necessary in today's changing environment.</li>
						<li>To mould and produce graduates who are academically prepared and imbued of moral strength and sense of integrity and accountability.</li>
						<li>To make every Theresian a committed Filipino who has the sense of common good and the ability to look beyond selfish interest; is disclined; hard-working; concerned to human development; and the building of Christian communities.</li>
						<li>To adopt methods of instruction that would focus on providing students with the tools for self-directed learning.</li>
						<li>To offer curricular programs that will develop competent professionals who will participate in the functions of society thus, improve quality of life.</li>
						<li>To implement continuing professional development programs for a well-meaning instruction, research and community extension.</li>
						<li>articipate in the mission of the church for the salvation of man through the work. word and life especially in his day-to-day relationship with God and fellowmen.</li>
					   </ol>
                    </div>
					

					
			</div>
			
		</div>
		<br><br><br><br>
		<div id="footer">
			<h2>&copy; Allright Reserved</h2>
			<div id="nav2">
				<ul>
					<li><a href="https://www.facebook.com/Saint-Theresa-College-Alumni-Tracer-708399509499392/"> <i class="fa fa-facebook" id="icon"></i></a></li>
					
				</ul>
			</div>
		</div>
	
	
	</body>
</html>	